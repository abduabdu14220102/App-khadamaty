package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.FreeNetCatalog
import com.example.model.NetworkOperator
import com.example.model.TelecomCodesCatalog
import com.example.security.CryptoManager
import com.example.service.RealTelephonyService
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

    @Test
    fun `read string from context`() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        val appName = context.getString(R.string.app_name)
        assertEquals("خدماتي", appName)
    }

    @Test
    fun `test operator detection from real Egyptian phone prefixes`() {
        assertEquals(NetworkOperator.VODAFONE, RealTelephonyService.detectOperatorFromNumber("01012345678"))
        assertEquals(NetworkOperator.ORANGE, RealTelephonyService.detectOperatorFromNumber("01234567890"))
        assertEquals(NetworkOperator.ETISALAT, RealTelephonyService.detectOperatorFromNumber("01198765432"))
        assertEquals(NetworkOperator.WE, RealTelephonyService.detectOperatorFromNumber("01555555555"))
    }

    @Test
    fun `test ocr scratch card pin extraction with noise and spaces matching HTML logic`() {
        val sampleOcrText = """
            Vodafone Recharge Card 50 EGP
            Code: 7894 1234 5678 90
            Valid until 2027/12
            S/N: 98127391823719
        """.trimIndent()
        val pin = CryptoManager.extractPinFromOcrText(sampleOcrText, NetworkOperator.VODAFONE)
        assertNotNull(pin)
        assertEquals("78941234567890", pin)
        assertEquals(14, pin?.length)
    }

    @Test
    fun `test reference HTML app ROI card extraction with scratched letters`() {
        val roiText = "  7894  O234  S678  90  "
        val pin = CryptoManager.extractPinFromOcrText(roiText, NetworkOperator.VODAFONE)
        assertEquals("78940234567890", pin)
    }

    @Test
    fun `test format recharge ussd regular and net only matching HTML buttons`() {
        val pin = "12345678901234"
        assertEquals("*858*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.VODAFONE, pin, false))
        assertEquals("*858*2*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.VODAFONE, pin, true))
        assertEquals("#102*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.ORANGE, pin, false))
        assertEquals("#102*2*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.ORANGE, pin, true))
        assertEquals("*555*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.ETISALAT, pin, false))
        assertEquals("*555*2*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.ETISALAT, pin, true))
        assertEquals("*555*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.WE, pin, false))
        assertEquals("*555*2*12345678901234#", RealTelephonyService.formatRechargeUssd(NetworkOperator.WE, pin, true))
    }

    @Test
    fun `test direct ussd cash transfer format`() {
        val vfCode = RealTelephonyService.formatCashTransferUssd(NetworkOperator.VODAFONE, "01012345678", "100")
        assertEquals("*9*7*01012345678*100#", vfCode)
        // Orange and Etisalat strictly support primary basic codes only as requested by user
        val ogCode = RealTelephonyService.formatCashTransferUssd(NetworkOperator.ORANGE, "01212345678", "50")
        assertEquals("#115#", ogCode)
        val etCode = RealTelephonyService.formatCashTransferUssd(NetworkOperator.ETISALAT, "01112345678", "75")
        assertEquals("*777#", etCode)
    }

    @Test
    fun `test card pin validation accepts 14 to 16 digits for all networks`() {
        for (op in NetworkOperator.values()) {
            val res14 = CryptoManager.validateCardPin(op, "12345678901234")
            assertTrue(res14.isValid)
            val res15 = CryptoManager.validateCardPin(op, "123456789012345")
            assertTrue(res15.isValid)
            val res16 = CryptoManager.validateCardPin(op, "1234567890123456")
            assertTrue(res16.isValid)
        }
    }

    @Test
    fun `test free net catalog and telecom catalog exist`() {
        assertTrue(FreeNetCatalog.allFreeCodes.isNotEmpty())
        assertTrue(TelecomCodesCatalog.allCodes.isNotEmpty())
        // Verify *890# featured Etisalat code is present
        assertTrue(FreeNetCatalog.allFreeCodes.any { it.code == "*890#" })
        assertTrue(TelecomCodesCatalog.allCodes.any { it.ussdCode == "*890#" })
    }
}
