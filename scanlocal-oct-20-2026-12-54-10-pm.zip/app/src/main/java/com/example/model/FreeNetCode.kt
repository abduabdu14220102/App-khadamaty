package com.example.model

enum class FreeNetCategory(val titleArabic: String) {
    DAILY_OFFERS("عروض يومية"),
    FOUR_G_GIFTS("هدايا الـ 4G"),
    APP_BONUS("مكافآت التطبيقات"),
    SEASONAL_PROMO("عروض حصرية"),
    PROTECTION("حماية الرصيد")
}

data class FreeNetCode(
    val id: String,
    val operator: NetworkOperator?,
    val title: String,
    val code: String,
    val quotaDescription: String,
    val validityPeriod: String,
    val condition: String,
    val category: FreeNetCategory,
    val isVerified: Boolean = true
)
