package com.example.model

enum class ServiceCategory(val titleArabic: String) {
    ACCOUNT_MANAGEMENT("إدارة الحساب والرصيد"),
    SMART_WALLETS("المحافظ الذكية"),
    EMERGENCY_BALANCE("سلفني وخدمات الطوارئ"),
    BUNDLES_INTERNET("باقات والإنترنت"),
    PRIVACY_CONTROL("التحكم والمكالمات")
}

data class TelecomServiceCode(
    val id: String,
    val network: NetworkOperator?,
    val category: ServiceCategory,
    val serviceName: String,
    val ussdCode: String,
    val note: String = ""
)
