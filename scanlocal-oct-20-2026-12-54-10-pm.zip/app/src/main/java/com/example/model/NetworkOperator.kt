package com.example.model

import androidx.compose.ui.graphics.Color
import com.example.ui.theme.EtisalatGreen
import com.example.ui.theme.OrangeEgypt
import com.example.ui.theme.VodafoneRed
import com.example.ui.theme.WePurple

enum class NetworkOperator(
    val id: String,
    val titleArabic: String,
    val titleEnglish: String,
    val prefix: String,
    val brandColor: Color,
    val rechargeLabel: String, // Matching HTML: 'شحن فليكس', 'شحن ميكس', 'شحن رصيد'
    val ussdRechargePrefix: String, // e.g. *858*
    val ussdBalanceCode: String,
    val ussdCashBalanceCode: String,
    val ussdMyNumberCode: String,
    val ussdInternetCode: String,
    val customerServiceNumber: String,
    val pinLengthDescription: String = "14 - 16 رقم",
    val pinRange: IntRange = 14..16,
    val codePattern: String
) {
    VODAFONE(
        id = "vodafone",
        titleArabic = "فودافون",
        titleEnglish = "Vodafone",
        prefix = "010",
        brandColor = VodafoneRed,
        rechargeLabel = "شحن فليكس",
        ussdRechargePrefix = "*858*",
        ussdBalanceCode = "*868*1#",
        ussdCashBalanceCode = "*9*13#",
        ussdMyNumberCode = "*878#",
        ussdInternetCode = "*2000#",
        customerServiceNumber = "888",
        pinLengthDescription = "14 - 16 رقم",
        pinRange = 14..16,
        codePattern = "14 إلى 16 رقماً"
    ),
    ORANGE(
        id = "orange",
        titleArabic = "أورنج",
        titleEnglish = "Orange",
        prefix = "012",
        brandColor = OrangeEgypt,
        rechargeLabel = "شحن رصيد",
        ussdRechargePrefix = "#102*",
        ussdBalanceCode = "#100#",
        ussdCashBalanceCode = "#115#",
        ussdMyNumberCode = "#119#",
        ussdInternetCode = "#100*4#",
        customerServiceNumber = "110",
        pinLengthDescription = "14 - 16 رقم",
        pinRange = 14..16,
        codePattern = "14 إلى 16 رقماً"
    ),
    ETISALAT(
        id = "etisalat",
        titleArabic = "اتصالات e&",
        titleEnglish = "e& (Etisalat)",
        prefix = "011",
        brandColor = EtisalatGreen,
        rechargeLabel = "شحن ميكس",
        ussdRechargePrefix = "*555*",
        ussdBalanceCode = "*555#",
        ussdCashBalanceCode = "*777#",
        ussdMyNumberCode = "*947#",
        ussdInternetCode = "*566#",
        customerServiceNumber = "333",
        pinLengthDescription = "14 - 16 رقم",
        pinRange = 14..16,
        codePattern = "14 إلى 16 رقماً"
    ),
    WE(
        id = "we",
        titleArabic = "وي (WE)",
        titleEnglish = "WE (Telecom Egypt)",
        prefix = "015",
        brandColor = WePurple,
        rechargeLabel = "شحن رصيد",
        ussdRechargePrefix = "*555*",
        ussdBalanceCode = "*550#",
        ussdCashBalanceCode = "*322#",
        ussdMyNumberCode = "*688#",
        ussdInternetCode = "*999#",
        customerServiceNumber = "111",
        pinLengthDescription = "14 - 16 رقم",
        pinRange = 14..16,
        codePattern = "14 إلى 16 رقماً"
    );

    fun formatUssdRechargeCode(pin: String): String {
        val cleanPin = pin.filter { it.isDigit() }
        return "$ussdRechargePrefix$cleanPin#"
    }

    fun formatUssdInternetOnlyCode(pin: String): String {
        val cleanPin = pin.filter { it.isDigit() }
        return when (this) {
            VODAFONE -> "*858*2*$cleanPin#"
            ORANGE -> "#102*2*$cleanPin#"
            ETISALAT -> "*555*2*$cleanPin#"
            WE -> "*555*2*$cleanPin#"
        }
    }
}
