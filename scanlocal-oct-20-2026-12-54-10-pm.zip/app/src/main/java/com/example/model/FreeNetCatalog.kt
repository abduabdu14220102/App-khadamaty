package com.example.model

object FreeNetCatalog {
    val allFreeCodes: List<FreeNetCode> = listOf(
        // ==================== ETISALAT (اتصالات e&) ====================
        FreeNetCode(
            id = "et_890_special",
            operator = NetworkOperator.ETISALAT,
            title = "⭐ كود *890# اتصالات (مميز 2 جيجا)",
            code = "*890#",
            quotaDescription = "2000 ميجابايت (2 جيجا) إنترنت هدية مميزة",
            validityPeriod = "عرض خاص متجدد لعملاء اتصالات",
            condition = "اطلب كود *890# مباشرة للحصول على 2 جيجا فوراً وبدون شروط",
            category = FreeNetCategory.FOUR_G_GIFTS
        ),
        FreeNetCode(
            id = "et_my_etisalat",
            operator = NetworkOperator.ETISALAT,
            title = "تطبيق ماي اتصالات (My Etisalat)",
            code = "*3030#",
            quotaDescription = "حتى 1000 ميجابايت إنترنت مجاني",
            validityPeriod = "يومي / أسبوعي",
            condition = "التسجيل والدخول اليومي على التطبيق",
            category = FreeNetCategory.APP_BONUS
        ),
        FreeNetCode(
            id = "et_surprise",
            operator = NetworkOperator.ETISALAT,
            title = "عرض اتصالات وعالمية (كود أساسي)",
            code = "*707#",
            quotaDescription = "عروض مفاجئة للإنترنت المجاني",
            validityPeriod = "24 ساعة",
            condition = "طلب الكود الأساسي المتجدد يومياً",
            category = FreeNetCategory.DAILY_OFFERS
        ),
        FreeNetCode(
            id = "et_smart_4g",
            operator = NetworkOperator.ETISALAT,
            title = "هدية شريحة 4G اتصالات",
            code = "*705#",
            quotaDescription = "1 جيجا بايت مجاناً",
            validityPeriod = "صالحة لـ 3 أيام",
            condition = "عند تفعيل هاتف يدعم 4G أو استبدال الشريحة",
            category = FreeNetCategory.FOUR_G_GIFTS
        ),
        FreeNetCode(
            id = "et_daily_211",
            operator = NetworkOperator.ETISALAT,
            title = "عروض الميجابايتس اليومية (كود أساسي)",
            code = "*211#",
            quotaDescription = "وحدات وميجابايتس إنترنت مجانية",
            validityPeriod = "24 ساعة",
            condition = "متاح لجميع عملاء اتصالات يومياً",
            category = FreeNetCategory.DAILY_OFFERS
        ),

        // ==================== VODAFONE (فودافون) ====================
        FreeNetCode(
            id = "vf_spin",
            operator = NetworkOperator.VODAFONE,
            title = "عجلة الحظ / تطبيق أنا فودافون",
            code = "*2000#",
            quotaDescription = "حتى 1000 ميجابايت وهدايا يومية",
            validityPeriod = "يومي / أسبوعي",
            condition = "دخول يومي على التطبيق أو طلب الكود",
            category = FreeNetCategory.APP_BONUS
        ),
        FreeNetCode(
            id = "vf_promo_4g",
            operator = NetworkOperator.VODAFONE,
            title = "عرض ترقية الـ 4G (1 جيجا مجاناً)",
            code = "*4#",
            quotaDescription = "1000 ميجابايت إنترنت سريع",
            validityPeriod = "صالحة لـ 3 أيام",
            condition = "عند تشغيل شريحة 4G لأول مرة",
            category = FreeNetCategory.FOUR_G_GIFTS
        ),
        FreeNetCode(
            id = "vf_offers_365",
            operator = NetworkOperator.VODAFONE,
            title = "عروض 365 اليومية للإنترنت المجاني",
            code = "*365#",
            quotaDescription = "ميجابايتس ووحدات مجانية أو مخفضة",
            validityPeriod = "24 ساعة",
            condition = "متاح لعملاء فودافون يومياً",
            category = FreeNetCategory.DAILY_OFFERS
        ),
        FreeNetCode(
            id = "vf_summer_promo",
            operator = NetworkOperator.VODAFONE,
            title = "عروض الصيف والـ Mega Promo",
            code = "*2020#",
            quotaDescription = "ميجابايتس إضافية عند التجديد",
            validityPeriod = "أسبوعي",
            condition = "طلب الكود قبل تجديد باقة فليكس",
            category = FreeNetCategory.SEASONAL_PROMO
        ),

        // ==================== ORANGE (أورنج) ====================
        FreeNetCode(
            id = "og_zero_offers",
            operator = NetworkOperator.ORANGE,
            title = "عروض الإنترنت اليومية والميجابايتس (كود أساسي)",
            code = "#0#",
            quotaDescription = "ميجابايتس مجانية وعروض متجددة",
            validityPeriod = "24 ساعة",
            condition = "كود أساسي متجدد يومياً بدون شروط",
            category = FreeNetCategory.DAILY_OFFERS
        ),
        FreeNetCode(
            id = "og_go_bonus",
            operator = NetworkOperator.ORANGE,
            title = "عرض Go ومكافآت My Orange",
            code = "#12#",
            quotaDescription = "ميجابايتس إضافية حسب الباقة",
            validityPeriod = "أسبوعي / شهري",
            condition = "عبر تطبيق My Orange أو الكود",
            category = FreeNetCategory.APP_BONUS
        ),
        FreeNetCode(
            id = "og_4g_upgrade",
            operator = NetworkOperator.ORANGE,
            title = "هدية الـ 4G من أورنج (2 جيجا)",
            code = "#4#",
            quotaDescription = "2000 ميجابايت (2 جيجا) مجانية",
            validityPeriod = "صالحة لـ 7 أيام",
            condition = "عند تفعيل هاتف يدعم 4G أو ترقية الشريحة",
            category = FreeNetCategory.FOUR_G_GIFTS
        ),
        FreeNetCode(
            id = "og_promo_222",
            operator = NetworkOperator.ORANGE,
            title = "عروض ومفاجآت أورنج الخاصة",
            code = "#222#",
            quotaDescription = "باقات إنترنت مخفضة وميجابايتس هدية",
            validityPeriod = "أسبوعي",
            condition = "لعملاء الكارت وخطوط الدفع المسبق",
            category = FreeNetCategory.SEASONAL_PROMO
        ),

        // ==================== WE (المصرية للاتصالات) ====================
        FreeNetCode(
            id = "we_gift_015",
            operator = NetworkOperator.WE,
            title = "عروض الـ Gift والإنترنت اليومي",
            code = "*015#",
            quotaDescription = "هدايا ومفاجآت تمنح نت مجاني",
            validityPeriod = "يومي",
            condition = "متاح لجميع عملاء 015 يومياً",
            category = FreeNetCategory.DAILY_OFFERS
        ),
        FreeNetCode(
            id = "we_points",
            operator = NetworkOperator.WE,
            title = "استبدال نقاط WE بوحدات إنترنت",
            code = "*333#",
            quotaDescription = "وحدات وميجابايتس مجانية",
            validityPeriod = "شهري",
            condition = "حسب رصيد النقاط المجمع من الاستهلاك",
            category = FreeNetCategory.APP_BONUS
        ),
        FreeNetCode(
            id = "we_nitro_gift",
            operator = NetworkOperator.WE,
            title = "عروض باقات نيترو الإضافية",
            code = "*999*015#",
            quotaDescription = "ميجابايتس مضاعفة على باقة نيترو",
            validityPeriod = "شهري",
            condition = "عند تجديد باقة نيترو عبر الكود",
            category = FreeNetCategory.SEASONAL_PROMO
        ),
        FreeNetCode(
            id = "we_promo_701",
            operator = NetworkOperator.WE,
            title = "هدية الشريحة الجديدة 015",
            code = "*701#",
            quotaDescription = "1000 ميجابايت إنترنت هدية",
            validityPeriod = "7 أيام",
            condition = "للخطوط الجديدة والمفعلة حديثاً",
            category = FreeNetCategory.FOUR_G_GIFTS
        ),

        // ==================== NTRA Unified ====================
        FreeNetCode(
            id = "ntra_stop_drain",
            operator = null,
            title = "حماية الرصيد - إلغاء الخدمات الترفيهية",
            code = "*155#",
            quotaDescription = "إلغاء أي اشتراك يخصم من الرصيد والنت",
            validityPeriod = "دائم",
            condition = "كود موحد من تنظيم الاتصالات لكل الشبكات في مصر",
            category = FreeNetCategory.PROTECTION
        )
    )
}
