package com.example.model

data class RechargeCard(
    val id: Long = System.currentTimeMillis(),
    val network: NetworkOperator,
    val rawPin: String,
    val maskedPin: String,
    val timestamp: Long = System.currentTimeMillis()
)
