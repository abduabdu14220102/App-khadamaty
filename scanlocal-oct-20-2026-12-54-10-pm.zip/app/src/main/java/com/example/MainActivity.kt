package com.example

import android.Manifest
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.ui.components.EditNumberDialog
import com.example.ui.components.KhedmatyBottomNav
import com.example.ui.components.KhedmatyTopBar
import com.example.ui.components.OcrCameraModal
import com.example.ui.screens.CardScannerScreen
import com.example.ui.screens.DashboardScreen
import com.example.ui.screens.FeedbackScreen
import com.example.ui.screens.FreeNetScreen
import com.example.ui.screens.TelecomCodesScreen
import com.example.ui.screens.WalletsScreen
import com.example.ui.theme.MyApplicationTheme
import com.example.ui.theme.NavyDark
import com.example.viewmodel.AppTab
import com.example.viewmodel.KhedmatyViewModel
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme {
                KhedmatyApp()
            }
        }
    }
}

@Composable
fun KhedmatyApp(viewModel: KhedmatyViewModel = viewModel()) {
    val context = LocalContext.current
    val uiState by viewModel.uiState.collectAsStateWithLifecycle()
    val snackbarHostState = remember { SnackbarHostState() }
    val scope = rememberCoroutineScope()

    // Real Hardware SIM & Telephony permission launcher
    val permissionsLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { _ ->
        viewModel.loadSimCards(context)
        viewModel.refreshNativeStats(context)
    }

    LaunchedEffect(Unit) {
        permissionsLauncher.launch(
            arrayOf(
                Manifest.permission.READ_PHONE_STATE,
                Manifest.permission.READ_PHONE_NUMBERS,
                Manifest.permission.CALL_PHONE,
                Manifest.permission.CAMERA,
                Manifest.permission.READ_CALL_LOG,
                Manifest.permission.READ_SMS
            )
        )
        viewModel.loadSimCards(context)
        viewModel.refreshNativeStats(context)
    }

    // Android hardware back button
    BackHandler(enabled = uiState.currentTab != AppTab.DASHBOARD) {
        viewModel.selectTab(AppTab.DASHBOARD)
    }

    // Notice message snackbar
    LaunchedEffect(uiState.noticeMessage) {
        uiState.noticeMessage?.let { msg ->
            scope.launch {
                snackbarHostState.showSnackbar(msg)
                viewModel.clearNotice()
            }
        }
    }

    Scaffold(
        modifier = Modifier.fillMaxSize(),
        containerColor = NavyDark,
        topBar = {
            KhedmatyTopBar(
                activeOperator = uiState.activeOperator,
                selectedSimSlot = uiState.selectedSimIndex,
                isDualSim = uiState.isDualSimDevice,
                onSimClick = {
                    val nextIndex = if (uiState.selectedSimIndex == 0 && uiState.installedSims.size > 1) 1 else 0
                    viewModel.switchSim(nextIndex)
                }
            )
        },
        bottomBar = {
            KhedmatyBottomNav(
                currentTab = uiState.currentTab,
                onTabSelected = { viewModel.selectTab(it) }
            )
        },
        snackbarHost = { SnackbarHost(snackbarHostState) }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (uiState.currentTab) {
                AppTab.DASHBOARD -> DashboardScreen(
                    uiState = uiState,
                    onNavigateTab = { viewModel.selectTab(it) },
                    onSelectSim = { viewModel.switchSim(it) },
                    onEditNumberClick = { viewModel.openEditNumberDialog() },
                    onRefreshSims = { viewModel.loadSimCards(context) },
                    onLaunchCameraModal = { viewModel.openCameraModal() },
                    onUpdateCardCode = { viewModel.updateCardCode(it) },
                    onRefreshStats = { viewModel.refreshNativeStats(context) },
                    onOpenNetTransfer = { viewModel.openNetTransferDialog() },
                    onOpenFlexCalc = { viewModel.openFlexCalculatorDialog() },
                    onOpenDailyLimit = { viewModel.openDailyLimitDialog() },
                    onOpenFlexGuide = { viewModel.openFlexTransferGuideDialog() },
                    onOpenUssdCompare = { viewModel.openUssdCompareDialog() }
                )
                AppTab.SCANNER -> CardScannerScreen(
                    uiState = uiState,
                    onSelectNetwork = { viewModel.setScannerNetwork(it) },
                    onProcessCard = { viewModel.processRechargeCard(it) }
                )
                AppTab.FREE_NET -> FreeNetScreen(
                    uiState = uiState,
                    onFilterChange = { op, cat -> viewModel.setFreeNetFilter(op, cat) }
                )
                AppTab.CODES -> TelecomCodesScreen(
                    uiState = uiState,
                    onFilterChange = { op, cat, q -> viewModel.setCodesFilter(op, cat, q) }
                )
                AppTab.WALLET_CODES -> WalletsScreen(
                    uiState = uiState,
                    onUpdateFields = { op, phone, amt -> viewModel.updateTransferFields(op, phone, amt) },
                    onExecuteTransferUssd = { ctx -> viewModel.executeCashTransferUssd(ctx) }
                )
                AppTab.FEEDBACK -> FeedbackScreen(
                    activeOperator = uiState.activeOperator
                )
            }

            // 🌟 Exact HTML Camera/OCR Modal adapted for instant scratch card reading
            if (uiState.isCameraModalOpen) {
                OcrCameraModal(
                    isOpen = uiState.isCameraModalOpen,
                    selectedNetwork = uiState.activeOperator,
                    onClose = { viewModel.closeCameraModal() },
                    onCodeRead = { scannedCode ->
                        viewModel.onCodeScannedFromCamera(scannedCode)
                    },
                    onShowToast = { msg ->
                        scope.launch {
                            snackbarHostState.showSnackbar(msg)
                        }
                    }
                )
            }

            // Dialog for editing phone number
            if (uiState.showEditNumberDialog) {
                EditNumberDialog(
                    initialPhone = uiState.activePhoneNumber,
                    onSave = { viewModel.saveManualPhoneNumber(it) },
                    onDismiss = { viewModel.closeEditNumberDialog() }
                )
            }

            // 🧮 Net Transfer Calculator Dialog
            if (uiState.showNetTransferDialog) {
                com.example.ui.components.NetTransferCalculatorDialog(
                    currentOperator = uiState.activeOperator,
                    onDismiss = { viewModel.closeNetTransferDialog() },
                    onExecuteDial = { ussdCode ->
                        viewModel.closeNetTransferDialog()
                        com.example.service.RealTelephonyService.dialUssd(context, ussdCode)
                    }
                )
            }

            // ⚡ Flexes Consumption Calculator Dialog
            if (uiState.showFlexCalculatorDialog) {
                com.example.ui.components.FlexCalculatorDialog(
                    onDismiss = { viewModel.closeFlexCalculatorDialog() }
                )
            }

            // 🔔 Daily Limit Dialog
            if (uiState.showDailyLimitDialog) {
                com.example.ui.components.DailyLimitDialog(
                    currentLimitMb = uiState.dailyLimitMb,
                    onSaveLimit = { newLimit -> viewModel.setDailyLimit(newLimit) },
                    onDismiss = { viewModel.closeDailyLimitDialog() }
                )
            }

            // 📖 Flexes Transfer Guide Dialog
            if (uiState.showFlexTransferGuideDialog) {
                com.example.ui.components.FlexTransferGuideDialog(
                    currentOperator = uiState.activeOperator,
                    onDismiss = { viewModel.closeFlexTransferGuideDialog() }
                )
            }

            // ⚖️ USSD Compare Dialog
            if (uiState.showUssdCompareDialog) {
                com.example.ui.components.UssdCompareDialog(
                    currentOperator = uiState.activeOperator,
                    onDismiss = { viewModel.closeUssdCompareDialog() },
                    onDialUssd = { ussdCode ->
                        viewModel.closeUssdCompareDialog()
                        com.example.service.RealTelephonyService.dialUssd(context, ussdCode)
                    }
                )
            }
        }
    }
}
