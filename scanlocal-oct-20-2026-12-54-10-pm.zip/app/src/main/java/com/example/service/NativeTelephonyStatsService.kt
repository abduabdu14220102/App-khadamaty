package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.app.usage.NetworkStats
import android.app.usage.NetworkStatsManager
import android.content.Context
import android.content.pm.PackageManager
import android.net.ConnectivityManager
import android.net.TrafficStats
import android.os.Build
import android.provider.CallLog
import android.provider.Telephony
import android.telephony.TelephonyManager
import androidx.core.content.ContextCompat
import com.example.model.NetworkOperator
import java.util.Calendar

data class CallUsageData(
    val sameNetMinutes: Int = 0,
    val otherNetMinutes: Int = 0,
    val totalMinutes: Int = 0,
    val incomingMinutes: Int = 0,
    val outgoingMinutes: Int = 0,
    val estimatedFlexesFromCalls: Int = 0
)

data class NetTransferCalculation(
    val amount: Double,
    val operator: NetworkOperator,
    val recipientPhone: String,
    val transferFeeEgp: Double,
    val totalDeductedEgp: Double,
    val netReceivedEgp: Double,
    val formattedConfirmationUssd: String,
    val ruleExplanationArabic: String
)

data class FlexConsumptionCalculation(
    val sameNetMinutes: Int,
    val otherNetMinutes: Int,
    val megabytes: Int,
    val smsCount: Int,
    val totalFlexesRequired: Int,
    val breakdownArabic: String
)

object NativeTelephonyStatsService {

    /**
     * Reads Mobile Data Usage (in Bytes) via NetworkStatsManager (Android 6.0+)
     * or fallback via TrafficStats.
     * Operates 100% offline, zero USSD fees, zero internet data needed.
     */
    @SuppressLint("MissingPermission")
    fun getMobileDataUsageBytes(context: Context, startTime: Long, endTime: Long): Long {
        val hasStatePerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                val networkStatsManager = context.getSystemService(Context.NETWORK_STATS_SERVICE) as? NetworkStatsManager
                val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager
                val subscriberId = if (hasStatePerm && Build.VERSION.SDK_INT < Build.VERSION_CODES.Q) {
                    try { telephonyManager?.subscriberId } catch (_: Exception) { null }
                } else null

                if (networkStatsManager != null) {
                    val bucket: NetworkStats.Bucket = networkStatsManager.querySummaryForDevice(
                        ConnectivityManager.TYPE_MOBILE,
                        subscriberId,
                        startTime,
                        endTime
                    )
                    val total = bucket.rxBytes + bucket.txBytes
                    if (total > 0L) return total
                }
            }
        } catch (_: Exception) {
            // Permission or system limitation fallback
        }

        // Fallback to TrafficStats mobile usage
        val mobileRx = TrafficStats.getMobileRxBytes()
        val mobileTx = TrafficStats.getMobileTxBytes()
        val total = if (mobileRx != TrafficStats.UNSUPPORTED.toLong() && mobileTx != TrafficStats.UNSUPPORTED.toLong()) {
            mobileRx + mobileTx
        } else {
            0L
        }
        return total.coerceAtLeast(0L)
    }

    /**
     * Calculates calls usage (minutes to same network vs other networks) using native CallLog
     * without any USSD fees.
     */
    fun getCallUsageStats(context: Context, startTime: Long, currentOperator: NetworkOperator): CallUsageData {
        val hasCallLogPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_CALL_LOG
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasCallLogPerm) {
            return CallUsageData()
        }

        var sameNetSec = 0
        var otherNetSec = 0
        var incomingSec = 0
        var outgoingSec = 0

        val projection = arrayOf(
            CallLog.Calls.NUMBER,
            CallLog.Calls.DURATION,
            CallLog.Calls.TYPE,
            CallLog.Calls.DATE
        )
        val selection = "${CallLog.Calls.DATE} >= ?"
        val selectionArgs = arrayOf(startTime.toString())

        try {
            val cursor = context.contentResolver.query(
                CallLog.Calls.CONTENT_URI,
                projection,
                selection,
                selectionArgs,
                "${CallLog.Calls.DATE} DESC"
            )

            cursor?.use {
                val numberIdx = it.getColumnIndex(CallLog.Calls.NUMBER)
                val durationIdx = it.getColumnIndex(CallLog.Calls.DURATION)
                val typeIdx = it.getColumnIndex(CallLog.Calls.TYPE)

                while (it.moveToNext()) {
                    val number = if (numberIdx != -1) it.getString(numberIdx) ?: "" else ""
                    val durationSec = if (durationIdx != -1) it.getInt(durationIdx) else 0
                    val type = if (typeIdx != -1) it.getInt(typeIdx) else 0

                    if (type == CallLog.Calls.OUTGOING_TYPE) {
                        outgoingSec += durationSec
                        val callOp = RealTelephonyService.detectOperatorFromNumber(number)
                        if (callOp == currentOperator) {
                            sameNetSec += durationSec
                        } else {
                            otherNetSec += durationSec
                        }
                    } else if (type == CallLog.Calls.INCOMING_TYPE) {
                        incomingSec += durationSec
                    }
                }
            }
        } catch (_: Exception) {
            // Return collected so far
        }

        val sameMin = (sameNetSec + 59) / 60
        val otherMin = (otherNetSec + 59) / 60
        val inMin = (incomingSec + 59) / 60
        val outMin = (outgoingSec + 59) / 60
        val totalMin = inMin + outMin
        // Standard Egyptian Flex logic: 1 min to same network = 1 flex, 1 min to other networks = 5 flexes
        val estimatedFlexes = (sameMin * 1) + (otherMin * 5)

        return CallUsageData(
            sameNetMinutes = sameMin,
            otherNetMinutes = otherMin,
            totalMinutes = totalMin,
            incomingMinutes = inMin,
            outgoingMinutes = outMin,
            estimatedFlexesFromCalls = estimatedFlexes
        )
    }

    /**
     * Reads sent SMS count via native Telephony.Sms provider without USSD.
     */
    fun getSentSmsCount(context: Context, startTime: Long): Int {
        val hasSmsPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_SMS
        ) == PackageManager.PERMISSION_GRANTED

        if (!hasSmsPerm) return 0

        var count = 0
        try {
            val uri = Telephony.Sms.Sent.CONTENT_URI
            val projection = arrayOf(Telephony.Sms.DATE)
            val selection = "${Telephony.Sms.DATE} >= ?"
            val selectionArgs = arrayOf(startTime.toString())

            val cursor = context.contentResolver.query(uri, projection, selection, selectionArgs, null)
            cursor?.use {
                count = it.count
            }
        } catch (_: Exception) {
            count = 0
        }
        return count
    }

    /**
     * Calculates Net Balance Transfer for Egyptian Operators:
     * - Vodafone: 2% transfer fee (min 0.20 EGP, max 5 EGP)
     * - Orange: 2% transfer fee (min 0.30 EGP)
     * - Etisalat: 2% transfer fee (min 0.30 EGP, max 4 EGP)
     * - WE: 2% transfer fee (min 0.30 EGP)
     */
    fun calculateNetTransfer(
        operator: NetworkOperator,
        amount: Double,
        recipientPhone: String
    ): NetTransferCalculation {
        val cleanPhone = recipientPhone.trim().replace(" ", "")
        val (fee, rule) = when (operator) {
            NetworkOperator.VODAFONE -> {
                val calc = (amount * 0.02).coerceIn(0.20, 5.00)
                calc to "فودافون: رسوم تحويل الرصيد 2% بحد أدنى 20 قرش وأقصى 5 جنيهات"
            }
            NetworkOperator.ORANGE -> {
                val calc = (amount * 0.02).coerceAtLeast(0.30)
                calc to "أورنج: رسوم تحويل الرصيد 2% بحد أدنى 30 قرش"
            }
            NetworkOperator.ETISALAT -> {
                val calc = (amount * 0.02).coerceIn(0.30, 4.00)
                calc to "اتصالات: رسوم تحويل الرصيد 2% بحد أدنى 30 قرش وأقصى 4 جنيهات"
            }
            NetworkOperator.WE -> {
                val calc = (amount * 0.02).coerceAtLeast(0.30)
                calc to "وي (WE): رسوم تحويل الرصيد 2% بحد أدنى 30 قرش"
            }
        }

        val totalDeducted = amount + fee
        val netReceived = amount

        val ussdCode = when (operator) {
            NetworkOperator.VODAFONE -> "*868*2*$cleanPhone*${amount.toInt()}#"
            NetworkOperator.ORANGE -> "#100*2# ثم ادخل الرقم $cleanPhone والمبلغ ${amount.toInt()}"
            NetworkOperator.ETISALAT -> "*770*$cleanPhone*${amount.toInt()}#"
            NetworkOperator.WE -> "*551*$cleanPhone*${amount.toInt()}#"
        }

        return NetTransferCalculation(
            amount = amount,
            operator = operator,
            recipientPhone = cleanPhone,
            transferFeeEgp = fee,
            totalDeductedEgp = totalDeducted,
            netReceivedEgp = netReceived,
            formattedConfirmationUssd = ussdCode,
            ruleExplanationArabic = rule
        )
    }

    /**
     * Calculates Flexes consumption based on Egyptian operators flex system:
     * - 1 min to same network = 1 flex
     * - 1 min to other network = 5 flexes
     * - 1 MB internet = 1 flex
     * - 1 SMS = 1 flex
     */
    fun calculateFlexes(
        sameNetMinutes: Int,
        otherNetMinutes: Int,
        megabytes: Int,
        smsCount: Int
    ): FlexConsumptionCalculation {
        val sameNetFlexes = sameNetMinutes * 1
        val otherNetFlexes = otherNetMinutes * 5
        val netFlexes = megabytes * 1
        val smsFlexes = smsCount * 1
        val total = sameNetFlexes + otherNetFlexes + netFlexes + smsFlexes

        val breakdown = "دقيقة لنفس الشبكة: $sameNetFlexes فليكس | دقيقة لشبكات أخرى: $otherNetFlexes فليكس | نت: $netFlexes فليكس | رسائل: $smsFlexes فليكس"

        return FlexConsumptionCalculation(
            sameNetMinutes = sameNetMinutes,
            otherNetMinutes = otherNetMinutes,
            megabytes = megabytes,
            smsCount = smsCount,
            totalFlexesRequired = total,
            breakdownArabic = breakdown
        )
    }

    /**
     * Returns the start of today in milliseconds.
     */
    fun getStartOfTodayMs(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }

    /**
     * Returns the start of current week in milliseconds.
     */
    fun getStartOfWeekMs(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_WEEK, firstDayOfWeek)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }

    /**
     * Returns the start of current month in milliseconds.
     */
    fun getStartOfMonthMs(): Long {
        val calendar = Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }
        return calendar.timeInMillis
    }
}
