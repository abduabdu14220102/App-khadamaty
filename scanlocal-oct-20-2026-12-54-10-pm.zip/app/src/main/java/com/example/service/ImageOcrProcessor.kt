package com.example.service

import android.graphics.Bitmap
import android.graphics.Color as AndroidColor
import android.graphics.Matrix
import androidx.camera.core.ImageProxy
import com.example.model.NetworkOperator
import com.example.security.CryptoManager
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.Text
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

data class OcrScanResult(
    val isSuccess: Boolean,
    val extractedPin: String?,
    val rawText: String,
    val confidence: Float,
    val statusMessage: String
)

object ImageOcrProcessor {

    private val recognizer by lazy {
        TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    }

    /**
     * Crops the exact 80% width x 25% height central ROI box matching the HTML reference:
     * .roi-overlay { width: 80%; height: 25%; }
     */
    fun cropRoiBitmap(source: Bitmap, rotationDegrees: Int): Bitmap {
        val rotated = if (rotationDegrees != 0) {
            val matrix = Matrix().apply { postRotate(rotationDegrees.toFloat()) }
            Bitmap.createBitmap(source, 0, 0, source.width, source.height, matrix, true)
        } else {
            source
        }

        val roiPercentWidth = 0.80f
        val roiPercentHeight = 0.25f

        val roiW = (rotated.width * roiPercentWidth).toInt().coerceIn(10, rotated.width)
        val roiH = (rotated.height * roiPercentHeight).toInt().coerceIn(10, rotated.height)
        val roiX = ((rotated.width - roiW) / 2).coerceIn(0, rotated.width - roiW)
        val roiY = ((rotated.height - roiH) / 2).coerceIn(0, rotated.height - roiH)

        return Bitmap.createBitmap(rotated, roiX, roiY, roiW, roiH)
    }

    /**
     * Tesseract/Leptonica Style Image Preprocessing:
     * Increases contrast and binarizes scratched card surface to clearly separate
     * printed matrix numbers from holographic scratch noise.
     */
    fun enhanceScratchCardImage(bitmap: Bitmap): Bitmap {
        val width = bitmap.width
        val height = bitmap.height
        val output = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)

        val pixels = IntArray(width * height)
        bitmap.getPixels(pixels, 0, width, 0, 0, width, height)

        var totalLum = 0L
        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val lum = (r * 299 + g * 587 + b * 114) / 1000
            totalLum += lum
        }
        val avgLum = (totalLum / pixels.size).toInt().coerceIn(60, 190)

        for (i in pixels.indices) {
            val c = pixels[i]
            val r = (c shr 16) and 0xFF
            val g = (c shr 8) and 0xFF
            val b = c and 0xFF
            val lum = (r * 299 + g * 587 + b * 114) / 1000

            // High-contrast binarization threshold
            val outVal = if (lum < avgLum) 0 else 255
            pixels[i] = (0xFF shl 24) or (outVal shl 16) or (outVal shl 8) or outVal
        }

        output.setPixels(pixels, 0, width, 0, 0, width, height)
        return output
    }

    /**
     * Processes the image frame completely offline.
     */
    const val MIN_CONFIDENCE_THRESHOLD = 75.0f

    /**
     * Processes the image frame completely offline.
     */
    suspend fun analyzeFrame(
        imageProxy: ImageProxy,
        operator: NetworkOperator? = null
    ): OcrScanResult = suspendCancellableCoroutine { continuation ->
        try {
            val bitmap = imageProxy.toBitmap()
            val rotation = imageProxy.imageInfo.rotationDegrees

            // 1. Crop ROI (80% x 25%)
            val roiCrop = cropRoiBitmap(bitmap, rotation)

            val inputImage = InputImage.fromBitmap(roiCrop, 0)
            recognizer.process(inputImage)
                .addOnSuccessListener { visionText ->
                    val text = visionText.text
                    val detectedPin = CryptoManager.extractPinFromOcrText(text, operator)

                    if (detectedPin != null) {
                        val confidence = calculateConfidence(visionText, detectedPin, roiCrop)
                        if (confidence >= MIN_CONFIDENCE_THRESHOLD) {
                            continuation.resume(
                                OcrScanResult(
                                    isSuccess = true,
                                    extractedPin = detectedPin,
                                    rawText = text,
                                    confidence = confidence,
                                    statusMessage = "✅ تم سحب الكود بنجاح (دقة: ${confidence.toInt()}%): $detectedPin"
                                )
                            )
                        } else {
                            continuation.resume(
                                OcrScanResult(
                                    isSuccess = false,
                                    extractedPin = null,
                                    rawText = text,
                                    confidence = confidence,
                                    statusMessage = "⚠️ خلي بالك من الإضاءة وخلي الصورة واضحة (دقة المسح: ${confidence.toInt()}%)"
                                )
                            )
                        }
                    } else {
                        // Try enhanced binarization pass
                        tryEnhancedPass(roiCrop, operator) { enhancedResult ->
                            continuation.resume(enhancedResult)
                        }
                    }
                }
                .addOnFailureListener {
                    continuation.resume(
                        OcrScanResult(
                            isSuccess = false,
                            extractedPin = null,
                            rawText = "",
                            confidence = 0f,
                            statusMessage = "⚠️ خلي بالك من الإضاءة وخلي الصورة واضحة"
                        )
                    )
                }
                .addOnCompleteListener {
                    imageProxy.close()
                }
        } catch (e: Exception) {
            imageProxy.close()
            continuation.resume(
                OcrScanResult(
                    isSuccess = false,
                    extractedPin = null,
                    rawText = "",
                    confidence = 0f,
                    statusMessage = "⚠️ خلي بالك من الإضاءة وخلي الصورة واضحة"
                )
            )
        }
    }

    private fun tryEnhancedPass(
        roiCrop: Bitmap,
        operator: NetworkOperator?,
        onComplete: (OcrScanResult) -> Unit
    ) {
        val enhanced = enhanceScratchCardImage(roiCrop)
        val inputImage = InputImage.fromBitmap(enhanced, 0)
        recognizer.process(inputImage)
            .addOnSuccessListener { visionText ->
                val detected = CryptoManager.extractPinFromOcrText(visionText.text, operator)
                if (detected != null) {
                    val confidence = calculateConfidence(visionText, detected, roiCrop)
                    if (confidence >= MIN_CONFIDENCE_THRESHOLD) {
                        onComplete(
                            OcrScanResult(
                                isSuccess = true,
                                extractedPin = detected,
                                rawText = visionText.text,
                                confidence = confidence,
                                statusMessage = "✅ تم سحب الكود بنجاح (دقة: ${confidence.toInt()}%): $detected"
                            )
                        )
                    } else {
                        onComplete(
                            OcrScanResult(
                                isSuccess = false,
                                extractedPin = null,
                                rawText = visionText.text,
                                confidence = confidence,
                                statusMessage = "⚠️ خلي بالك من الإضاءة وخلي الصورة واضحة (دقة المسح: ${confidence.toInt()}%)"
                            )
                        )
                    }
                } else {
                    onComplete(
                        OcrScanResult(
                            isSuccess = false,
                            extractedPin = null,
                            rawText = visionText.text,
                            confidence = 0f,
                            statusMessage = "⚠️ خلي بالك من الإضاءة وخلي الصورة واضحة"
                        )
                    )
                }
            }
            .addOnFailureListener {
                onComplete(
                    OcrScanResult(
                        isSuccess = false,
                        extractedPin = null,
                        rawText = "",
                        confidence = 0f,
                        statusMessage = "⚠️ خلي بالك من الإضاءة وخلي الصورة واضحة"
                    )
                )
            }
    }

    /**
     * Calculates real confidence based on ML Kit text confidences and physical image lighting/contrast.
     * If lighting is dim or contrast is blurry, confidence drops below 75% to trigger the warning.
     */
    fun calculateConfidence(visionText: Text, pinCandidate: String? = null, roiBitmap: Bitmap? = null): Float {
        var mlKitTotal = 0f
        var mlKitCount = 0
        for (block in visionText.textBlocks) {
            for (line in block.lines) {
                line.confidence?.let { conf ->
                    mlKitTotal += conf
                    mlKitCount++
                }
            }
        }

        var imageQualityScore = 85.0f
        if (roiBitmap != null) {
            val w = roiBitmap.width
            val h = roiBitmap.height
            val sampleCount = 400
            val stepX = (w / 20).coerceAtLeast(1)
            val stepY = (h / 20).coerceAtLeast(1)

            var sumLum = 0.0
            var sumLumSq = 0.0
            var count = 0

            for (y in 0 until h step stepY) {
                for (x in 0 until w step stepX) {
                    val pixel = roiBitmap.getPixel(x, y)
                    val r = (pixel shr 16) and 0xFF
                    val g = (pixel shr 8) and 0xFF
                    val b = pixel and 0xFF
                    val lum = 0.299 * r + 0.587 * g + 0.114 * b
                    sumLum += lum
                    sumLumSq += lum * lum
                    count++
                }
            }

            if (count > 0) {
                val meanLum = sumLum / count
                val variance = (sumLumSq / count) - (meanLum * meanLum)
                val stdDev = if (variance > 0) Math.sqrt(variance) else 0.0

                // Lighting check: Bad lighting if too dark (< 50) or overexposed (> 215) or low contrast (< 25)
                if (meanLum < 50.0 || meanLum > 215.0 || stdDev < 25.0) {
                    imageQualityScore = 62.0f // Drops strictly below 75%
                } else if (stdDev < 35.0 || meanLum < 65.0) {
                    imageQualityScore = 70.0f // Marginal lighting, below 75%
                } else {
                    imageQualityScore = 88.0f // Clear and well-lit
                }
            }
        }

        if (mlKitCount > 0) {
            val mlKitAvg = (mlKitTotal / mlKitCount) * 100f
            return (mlKitAvg * 0.5f + imageQualityScore * 0.5f)
        }

        if (pinCandidate != null && pinCandidate.length in 14..16 && pinCandidate.all { it.isDigit() }) {
            return imageQualityScore
        }

        return 65.0f
    }
}
