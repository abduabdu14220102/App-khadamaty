package com.example.service

import android.Manifest
import android.annotation.SuppressLint
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.telephony.SubscriptionInfo
import android.telephony.SubscriptionManager
import android.telephony.TelephonyManager
import android.widget.Toast
import androidx.core.content.ContextCompat
import com.example.model.NetworkOperator

data class RealSimInfo(
    val slotIndex: Int,
    val displayName: String,
    val carrierName: String,
    val detectedOperator: NetworkOperator,
    val rawPhoneNumber: String?,
    val countryIso: String,
    val subscriptionId: Int
)

data class WalletShortcutCode(
    val id: String,
    val operator: NetworkOperator,
    val title: String,
    val ussdCode: String,
    val description: String,
    val isPrimary: Boolean = false
)

object RealTelephonyService {

    /**
     * Constructs regular or internet-only USSD recharge code matching the HTML app.
     */
    fun formatRechargeUssd(operator: NetworkOperator, pin: String, isNetOnly: Boolean = false): String {
        val cleanPin = pin.filter { it.isDigit() }
        return if (isNetOnly) {
            operator.formatUssdInternetOnlyCode(cleanPin)
        } else {
            operator.formatUssdRechargeCode(cleanPin)
        }
    }

    /**
     * Constructs the cash transfer USSD code.
     * Note: Orange and Etisalat in Egypt do NOT support direct parameter shortcuts on their USSD gateways;
     * they strictly require the official primary codes (#115# / *777#) to interactively transfer.
     */
    fun formatCashTransferUssd(operator: NetworkOperator, recipientPhone: String, amount: String): String {
        val cleanPhone = recipientPhone.trim().replace(" ", "").replace("-", "")
        val cleanAmount = amount.trim()
        return when (operator) {
            NetworkOperator.VODAFONE -> {
                if (cleanPhone.isNotBlank() && cleanAmount.isNotBlank()) "*9*7*$cleanPhone*$cleanAmount#" else "*9#"
            }
            NetworkOperator.ORANGE -> "#115#" // Orange strictly supports primary basic code only
            NetworkOperator.ETISALAT -> "*777#" // Etisalat strictly supports primary basic code only
            NetworkOperator.WE -> "*322#" // WE Pay interactive primary code
        }
    }

    fun getWalletShortcuts(operator: NetworkOperator): List<WalletShortcutCode> {
        return when (operator) {
            NetworkOperator.VODAFONE -> listOf(
                WalletShortcutCode("vf_w_menu", operator, "فودافون كاش - القائمة", "*9#", "القائمة الرئيسية للخدمات", true),
                WalletShortcutCode("vf_w_trf", operator, "تحويل أموال فودافون كاش", "*9*7*الرقم*المبلغ#", "تحويل فوري لأي محفظة في مصر", true),
                WalletShortcutCode("vf_w_bal", operator, "استعلام رصيد المحفظة", "*9*13#", "معرفة رصيدك المتاح بالكاش"),
                WalletShortcutCode("vf_w_vcn", operator, "كارت شراء أونلاين (VCN)", "*9*100#", "إنشاء فيزا افتراضية صالحة 24 ساعة"),
                WalletShortcutCode("vf_w_atm", operator, "سحب كاش من الـ ATM", "*9*22#", "الحصول على كود السحب من الصراف الآلي"),
                WalletShortcutCode("vf_w_bills", operator, "دفع الفواتير واشتراك النت", "*9*105#", "فواتير كهرباء وغاز ومياه ومرافق")
            )
            NetworkOperator.ORANGE -> listOf(
                WalletShortcutCode("og_w_menu", operator, "أورنج كاش - القائمة الرئيسية (كود أساسي)", "#115#", "الكود المعتمد الوحيد: اطلب #115# للتحويل والسحب والاستعلام", true),
                WalletShortcutCode("og_w_trf", operator, "تحويل أموال أورنج كاش", "#115#", "كود أساسي: اطلب #115# ثم اختر 1 للتحويل الفوري", true),
                WalletShortcutCode("og_w_atm", operator, "سحب نقدي ATM", "#115#", "كود أساسي: اطلب #115# ثم اختر خيار السحب", false),
                WalletShortcutCode("og_w_bills", operator, "سداد فواتير وشحن", "#115#", "كود أساسي: اطلب #115# ثم اختر سداد الفواتير", false)
            )
            NetworkOperator.ETISALAT -> listOf(
                WalletShortcutCode("et_w_menu", operator, "اتصالات كاش - القائمة الرئيسية (كود أساسي)", "*777#", "الكود المعتمد الوحيد: اطلب *777# للتحويل والاستعلام والرصيد", true),
                WalletShortcutCode("et_w_trf", operator, "تحويل أموال اتصالات كاش", "*777#", "كود أساسي: اطلب *777# ثم اختر 1 لتحويل الأموال", true),
                WalletShortcutCode("et_w_bal", operator, "استعلام رصيد اتصالات كاش", "*777#", "كود أساسي: اطلب *777# ثم اختر استعلام الرصيد", false),
                WalletShortcutCode("et_w_atm", operator, "سحب من ماكينة ATM", "*777#", "كود أساسي: اطلب *777# لطلب رقم السحب المؤقت", false)
            )
            NetworkOperator.WE -> listOf(
                WalletShortcutCode("we_w_menu", operator, "وي باي (WE Pay) - كود أساسي", "*322#", "القائمة الرئيسية لخدمات وي باي", true),
                WalletShortcutCode("we_w_trf", operator, "تحويل نقود وي باي", "*322#", "إرسال أموال لرقم محفظة عبر القائمة", true),
                WalletShortcutCode("we_w_atm", operator, "سحب ATM وي باي", "*322#", "سحب نقدي من الصراف الآلي", false)
            )
        }
    }

    /**
     * Cleans and normalizes Egyptian phone numbers from international to local format (01xxxxxxxxx).
     */
    fun normalizeEgyptianPhoneNumber(raw: String?): String? {
        if (raw.isNullOrBlank()) return null
        var clean = raw.trim().replace(" ", "").replace("-", "")
        if (clean.startsWith("+20")) {
            clean = "0" + clean.removePrefix("+20")
        } else if (clean.startsWith("0020")) {
            clean = "0" + clean.removePrefix("0020")
        } else if (clean.startsWith("20") && clean.length >= 12) {
            clean = "0" + clean.removePrefix("20")
        }
        return if (clean.length >= 11 && (clean.startsWith("010") || clean.startsWith("011") || clean.startsWith("012") || clean.startsWith("015"))) {
            clean
        } else {
            clean.ifBlank { null }
        }
    }

    /**
     * Detects Egyptian mobile operator from phone prefix:
     * 010 -> Vodafone
     * 011 -> Etisalat (e&)
     * 012 -> Orange
     * 015 -> WE
     */
    fun detectOperatorFromNumber(phoneNumber: String): NetworkOperator {
        val clean = normalizeEgyptianPhoneNumber(phoneNumber) ?: phoneNumber.trim()
        return when {
            clean.startsWith("010") -> NetworkOperator.VODAFONE
            clean.startsWith("011") -> NetworkOperator.ETISALAT
            clean.startsWith("012") -> NetworkOperator.ORANGE
            clean.startsWith("015") -> NetworkOperator.WE
            else -> NetworkOperator.VODAFONE
        }
    }

    fun detectOperatorByName(carrierName: String, numericOperator: String? = null): NetworkOperator {
        val num = numericOperator?.trim() ?: ""
        if (num == "60201" || num.startsWith("60201") || num == "602-01") return NetworkOperator.ORANGE
        if (num == "60202" || num.startsWith("60202") || num == "602-02") return NetworkOperator.VODAFONE
        if (num == "60203" || num.startsWith("60203") || num == "602-03") return NetworkOperator.ETISALAT
        if (num == "60204" || num.startsWith("60204") || num == "602-04") return NetworkOperator.WE

        val lower = carrierName.lowercase().trim()
        return when {
            lower.contains("oran") || lower.contains("mobinil") || lower.contains("أورنج") ||
                    lower.contains("اورنج") || lower.contains("ecms") || lower.contains("egy 01") ||
                    lower.contains("60201") -> NetworkOperator.ORANGE

            lower.contains("etis") || lower.contains("e&") || lower.contains("اتصالات") ||
                    lower.contains("egy 03") || lower.contains("60203") -> NetworkOperator.ETISALAT

            lower.contains("we") || lower.contains("telecom") || lower.contains("المصرية") ||
                    lower.contains("وي") || lower.contains("te") || lower.contains("egy 04") ||
                    lower.contains("60204") -> NetworkOperator.WE

            lower.contains("voda") || lower.contains("فودافون") || lower.contains("egy 02") ||
                    lower.contains("60202") -> NetworkOperator.VODAFONE

            else -> NetworkOperator.VODAFONE
        }
    }

    @SuppressLint("MissingPermission")
    fun getInstalledSimCards(context: Context): List<RealSimInfo> {
        val simList = mutableListOf<RealSimInfo>()
        val hasStatePerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.READ_PHONE_STATE
        ) == PackageManager.PERMISSION_GRANTED
        val telephonyManager = context.getSystemService(Context.TELEPHONY_SERVICE) as? TelephonyManager

        if (!hasStatePerm) {
            telephonyManager?.let { tm ->
                val numOp = tm.simOperator.ifBlank { tm.networkOperator }
                val carrier = tm.simOperatorName.ifBlank { tm.networkOperatorName.ifBlank { "شريحة 1" } }
                val op = detectOperatorByName(carrier, numOp)
                simList.add(
                    RealSimInfo(
                        slotIndex = 0,
                        displayName = "شريحة 1 (${op.titleArabic})",
                        carrierName = carrier,
                        detectedOperator = op,
                        rawPhoneNumber = null,
                        countryIso = tm.simCountryIso.ifBlank { "eg" },
                        subscriptionId = 1
                    )
                )
            }
            return simList
        }

        try {
            val subscriptionManager = context.getSystemService(Context.TELEPHONY_SUBSCRIPTION_SERVICE) as? SubscriptionManager
            val activeList: List<SubscriptionInfo>? = subscriptionManager?.activeSubscriptionInfoList
            if (!activeList.isNullOrEmpty()) {
                for (info in activeList) {
                    val carrier = info.carrierName?.toString()?.ifBlank {
                        info.displayName?.toString()
                    } ?: "شريحة ${info.simSlotIndex + 1}"

                    val mccMnc = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                        "${info.mccString ?: ""}${info.mncString ?: ""}"
                    } else {
                        ""
                    }

                    val hasNumberPerm = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
                        ContextCompat.checkSelfPermission(context, Manifest.permission.READ_PHONE_NUMBERS) == PackageManager.PERMISSION_GRANTED
                    } else {
                        hasStatePerm
                    }

                    var rawPhone: String? = null
                    if (hasNumberPerm) {
                        rawPhone = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU && subscriptionManager != null) {
                            try {
                                subscriptionManager.getPhoneNumber(info.subscriptionId)
                            } catch (e: Exception) {
                                info.number
                            }
                        } else {
                            info.number
                        }
                    }

                    if (rawPhone.isNullOrBlank() && hasStatePerm && telephonyManager != null) {
                        try {
                            rawPhone = telephonyManager.line1Number
                        } catch (e: Exception) {
                            // ignore
                        }
                    }

                    val normalizedPhone = normalizeEgyptianPhoneNumber(rawPhone)

                    val detectedOp = if (!normalizedPhone.isNullOrBlank()) {
                        detectOperatorFromNumber(normalizedPhone)
                    } else {
                        detectOperatorByName(carrier, mccMnc.ifBlank { telephonyManager?.simOperator })
                    }

                    simList.add(
                        RealSimInfo(
                            slotIndex = info.simSlotIndex,
                            displayName = "شريحة ${info.simSlotIndex + 1}: ${detectedOp.titleArabic}",
                            carrierName = carrier,
                            detectedOperator = detectedOp,
                            rawPhoneNumber = normalizedPhone,
                            countryIso = info.countryIso ?: "eg",
                            subscriptionId = info.subscriptionId
                        )
                    )
                }
            } else if (telephonyManager != null) {
                val numOp = telephonyManager.simOperator.ifBlank { telephonyManager.networkOperator }
                val carrier = telephonyManager.simOperatorName.ifBlank { telephonyManager.networkOperatorName.ifBlank { "شبكة المحمول" } }
                val op = detectOperatorByName(carrier, numOp)
                simList.add(
                    RealSimInfo(
                        slotIndex = 0,
                        displayName = "شريحة 1 (${op.titleArabic})",
                        carrierName = carrier,
                        detectedOperator = op,
                        rawPhoneNumber = null,
                        countryIso = telephonyManager.simCountryIso.ifBlank { "eg" },
                        subscriptionId = 1
                    )
                )
            }
        } catch (e: Exception) {
            // graceful fallback
        }

        if (simList.isEmpty()) {
            simList.add(
                RealSimInfo(
                    slotIndex = 0,
                    displayName = "شريحة 1 (فودافون)",
                    carrierName = "Vodafone EG",
                    detectedOperator = NetworkOperator.VODAFONE,
                    rawPhoneNumber = null,
                    countryIso = "eg",
                    subscriptionId = 1
                )
            )
        }
        return simList.sortedBy { it.slotIndex }
    }

    /**
     * Executes direct dialing code immediately!
     * With CALL_PHONE permission granted, directly executes via ACTION_CALL without manual tap.
     * Otherwise falls back safely to ACTION_DIAL.
     */
    fun dialUssd(context: Context, dialCode: String) {
        val hasCallPerm = ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.CALL_PHONE
        ) == PackageManager.PERMISSION_GRANTED
        val encodedUri = Uri.parse("tel:" + Uri.encode(dialCode))
        try {
            if (hasCallPerm) {
                val callIntent = Intent(Intent.ACTION_CALL, encodedUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(callIntent)
            } else {
                val dialIntent = Intent(Intent.ACTION_DIAL, encodedUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)
            }
        } catch (e: Exception) {
            try {
                val dialIntent = Intent(Intent.ACTION_DIAL, encodedUri).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                context.startActivity(dialIntent)
            } catch (ex: Exception) {
                Toast.makeText(context, "كود الخدمة: $dialCode", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun copyToClipboard(context: Context, text: String, toastMessage: String = "تم نسخ الكود بنجاح!") {
        try {
            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
            val clip = ClipData.newPlainText("TELECOM_CODE", text)
            clipboard.setPrimaryClip(clip)
            Toast.makeText(context, toastMessage, Toast.LENGTH_SHORT).show()
        } catch (e: Exception) {
            // ignore
        }
    }
}
