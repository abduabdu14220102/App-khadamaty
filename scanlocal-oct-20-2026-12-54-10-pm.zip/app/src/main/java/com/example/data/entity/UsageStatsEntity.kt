package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "usage_stats_snapshots")
data class UsageStatsSnapshotEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val simSlotIndex: Int = 0,
    val operatorId: String = "VODAFONE",
    val dateStr: String,
    val timestamp: Long = System.currentTimeMillis(),
    val mobileDataBytesToday: Long = 0L,
    val mobileDataBytesWeek: Long = 0L,
    val mobileDataBytesMonth: Long = 0L,
    val callMinutesSameNet: Int = 0,
    val callMinutesOtherNet: Int = 0,
    val totalCallMinutes: Int = 0,
    val smsCountSent: Int = 0,
    val estimatedFlexesUsed: Int = 0,
    val estimatedRemainingBalanceEgp: Double = 0.0,
    val dailyLimitMb: Int = 500,
    val bundleExpiryDate: String? = null
)
