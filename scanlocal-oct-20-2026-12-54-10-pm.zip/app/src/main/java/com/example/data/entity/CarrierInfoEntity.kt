package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "carrier_info")
data class CarrierInfoEntity(
    @PrimaryKey val simSlotIndex: Int,
    val operatorId: String,
    val carrierName: String,
    val phoneNumber: String,
    val iccId: String? = null,
    val subscriptionId: Int = -1,
    val isDefaultData: Boolean = false,
    val lastUpdatedTimestamp: Long = System.currentTimeMillis()
)
