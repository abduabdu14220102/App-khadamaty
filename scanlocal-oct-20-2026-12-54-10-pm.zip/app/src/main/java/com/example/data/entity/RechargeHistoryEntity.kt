package com.example.data.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "recharge_history")
data class RechargeHistoryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val operatorId: String,
    val maskedPin: String,
    val isNetOnly: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val notes: String = ""
)
