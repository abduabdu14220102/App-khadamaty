package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.RechargeHistoryEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface RechargeHistoryDao {
    @Query("SELECT * FROM recharge_history ORDER BY timestamp DESC")
    fun getAllRechargeHistoryFlow(): Flow<List<RechargeHistoryEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertRecharge(record: RechargeHistoryEntity): Long

    @Query("DELETE FROM recharge_history WHERE id = :id")
    suspend fun deleteById(id: Long)

    @Query("DELETE FROM recharge_history")
    suspend fun clearAll()
}
