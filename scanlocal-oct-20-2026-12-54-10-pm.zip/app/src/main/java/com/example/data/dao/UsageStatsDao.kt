package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.UsageStatsSnapshotEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface UsageStatsDao {
    @Query("SELECT * FROM usage_stats_snapshots WHERE simSlotIndex = :slotIndex ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestSnapshot(slotIndex: Int): UsageStatsSnapshotEntity?

    @Query("SELECT * FROM usage_stats_snapshots WHERE simSlotIndex = :slotIndex ORDER BY timestamp DESC LIMIT 1")
    fun getLatestSnapshotFlow(slotIndex: Int): Flow<UsageStatsSnapshotEntity?>

    @Query("SELECT * FROM usage_stats_snapshots WHERE simSlotIndex = :slotIndex ORDER BY timestamp DESC LIMIT 30")
    fun getRecentSnapshotsFlow(slotIndex: Int): Flow<List<UsageStatsSnapshotEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSnapshot(snapshot: UsageStatsSnapshotEntity): Long

    @Query("DELETE FROM usage_stats_snapshots WHERE timestamp < :olderThanTimestamp")
    suspend fun deleteOldSnapshots(olderThanTimestamp: Long)
}
