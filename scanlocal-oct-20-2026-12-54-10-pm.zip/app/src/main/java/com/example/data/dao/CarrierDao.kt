package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.entity.CarrierInfoEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface CarrierDao {
    @Query("SELECT * FROM carrier_info WHERE simSlotIndex = :slotIndex LIMIT 1")
    suspend fun getCarrierForSlot(slotIndex: Int): CarrierInfoEntity?

    @Query("SELECT * FROM carrier_info ORDER BY simSlotIndex ASC")
    fun getAllCarriersFlow(): Flow<List<CarrierInfoEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCarrier(carrier: CarrierInfoEntity)

    @Query("DELETE FROM carrier_info")
    suspend fun clearAll()
}
