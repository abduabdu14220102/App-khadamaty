package com.example.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.dao.CarrierDao
import com.example.data.dao.RechargeHistoryDao
import com.example.data.dao.UsageStatsDao
import com.example.data.entity.CarrierInfoEntity
import com.example.data.entity.RechargeHistoryEntity
import com.example.data.entity.UsageStatsSnapshotEntity

@Database(
    entities = [
        CarrierInfoEntity::class,
        UsageStatsSnapshotEntity::class,
        RechargeHistoryEntity::class
    ],
    version = 1,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun carrierDao(): CarrierDao
    abstract fun usageStatsDao(): UsageStatsDao
    abstract fun rechargeHistoryDao(): RechargeHistoryDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "khedmaty_room.db"
                )
                    .fallbackToDestructiveMigration()
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
