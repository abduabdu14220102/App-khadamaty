package com.example.security

import com.example.model.NetworkOperator
import java.util.regex.Pattern

object CryptoManager {
    /**
     * Cleans OCR digits specifically for candidate PIN strings.
     * Replaces common OCR character confusions (O/o -> 0, I/l/| -> 1, S/s -> 5, B -> 8, Z/z -> 2).
     */
    fun cleanOcrDigits(rawText: String): String {
        val preprocessed = rawText
            .replace('O', '0')
            .replace('o', '0')
            .replace('I', '1')
            .replace('l', '1')
            .replace('|', '1')
            .replace('i', '1')
            .replace('B', '8')
            .replace('S', '5')
            .replace('s', '5')
            .replace('Z', '2')
            .replace('z', '2')
        return preprocessed.filter { it.isDigit() }
    }

    /**
     * Formats masked PIN for secure on-screen display (e.g. **********1234).
     */
    fun maskPin(pin: String): String {
        val clean = pin.filter { it.isDigit() }
        if (clean.length < 6) return clean
        val visibleCount = 4
        val maskedCount = clean.length - visibleCount
        val maskedPrefix = "*".repeat(maskedCount)
        val suffix = clean.takeLast(visibleCount)
        return (maskedPrefix + suffix).chunked(4).joinToString(" ")
    }

    /**
     * Replicates the exact HTML engine extraction logic:
     * 1. Extracts pure digits inside the 80%x25% ROI: text.replace(/[^0-9]/g, '').trim()
     * 2. If cleanText.length >= 10, extracts candidate slice(0, targetLength)
     * 3. Multi-pass inspection to guarantee zero missing digits even with scratch marks.
     */
    /**
     * Extracts a valid scratch card PIN (14 to 16 digits for all Egyptian networks).
     */
    fun extractPinFromOcrText(fullText: String, operator: NetworkOperator? = null): String? {
        // 1. Look for any valid 14..16 digits sequence (16, 15, 14 digits)
        for (len in listOf(16, 15, 14)) {
            val regex = Pattern.compile("(?<!\\d)(?:\\d[\\s\\-]?){$len}(?!\\d)")
            val matcher = regex.matcher(fullText)
            if (matcher.find()) {
                val candidate = matcher.group().filter { it.isDigit() }
                if (candidate.length == len) {
                    return candidate
                }
            }
        }

        // 2. Line by line inspection after stripping common prefixes
        val lines = fullText.split("\n", "\r")
        for (line in lines) {
            val stripped = line.replace(Regex("(?i)^(Code|PIN|Serial|S/N|كود|رقم|الكارت)\\s*[:\\-]?"), "").trim()
            val digits = stripped.filter { it.isDigit() }
            if (digits.length in 14..16) {
                return digits
            }
        }

        // 3. OCR Character substitution (Handling scratched characters like O -> 0, S -> 5, B -> 8)
        for (len in listOf(16, 15, 14)) {
            val fuzzyRegex = Pattern.compile("(?<![a-zA-Z0-9])(?:[0-9OIlBSsZz][\\s\\-]?){$len}(?![a-zA-Z0-9])")
            val fuzzyMatcher = fuzzyRegex.matcher(fullText)
            if (fuzzyMatcher.find()) {
                val candidate = cleanOcrDigits(fuzzyMatcher.group())
                if (candidate.length == len) {
                    return candidate
                }
            }
        }

        // 4. Clean digits fallback (inside the central cropped ROI)
        val cleanDigits = cleanOcrDigits(fullText)
        if (cleanDigits.length in 14..16) {
            return cleanDigits
        } else if (cleanDigits.length > 16) {
            return cleanDigits.take(16)
        }

        return null
    }

    fun validateCardPin(network: NetworkOperator, rawPin: String): ValidationResult {
        val clean = cleanOcrDigits(rawPin)
        if (clean.length < 14) {
            val missing = 14 - clean.length
            return ValidationResult(
                isValid = false,
                sanitizedPin = clean,
                errorReason = "الكود غير مكتمل (ناقص $missing أرقام، كود الشحن من 14 إلى 16 رقماً)"
            )
        }
        if (clean.length > 16) {
            val candidate = clean.take(16)
            return ValidationResult(
                isValid = true,
                sanitizedPin = candidate,
                warning = "تم تقليص الكود لـ 16 رقماً كحد أقصى"
            )
        }
        return ValidationResult(
            isValid = true,
            sanitizedPin = clean
        )
    }

    data class ValidationResult(
        val isValid: Boolean,
        val sanitizedPin: String,
        val errorReason: String? = null,
        val warning: String? = null
    )
}
