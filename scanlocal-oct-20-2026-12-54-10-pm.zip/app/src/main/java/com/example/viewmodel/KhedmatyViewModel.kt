package com.example.viewmodel

import android.app.Application
import android.content.Context
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.entity.CarrierInfoEntity
import com.example.data.entity.RechargeHistoryEntity
import com.example.data.entity.UsageStatsSnapshotEntity
import com.example.model.FreeNetCategory
import com.example.model.NetworkOperator
import com.example.model.RechargeCard
import com.example.model.ServiceCategory
import com.example.security.CryptoManager
import com.example.service.CallUsageData
import com.example.service.FlexConsumptionCalculation
import com.example.service.NativeTelephonyStatsService
import com.example.service.NetTransferCalculation
import com.example.service.RealSimInfo
import com.example.service.RealTelephonyService
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

enum class AppTab(val titleArabic: String) {
    DASHBOARD("الرئيسية"),
    SCANNER("قارئ الكارت"),
    FREE_NET("نت مجاني"),
    CODES("دليل الأكواد"),
    WALLET_CODES("المحافظ الذكية"),
    FEEDBACK("تواصل ومقترحات")
}

data class KhedmatyUiState(
    val currentTab: AppTab = AppTab.DASHBOARD,
    val installedSims: List<RealSimInfo> = emptyList(),
    val selectedSimIndex: Int = 0,
    val activeOperator: NetworkOperator = NetworkOperator.VODAFONE,
    val activePhoneNumber: String = "01012345678",
    val activeCarrierName: String = "Vodafone",
    val isDualSimDevice: Boolean = false,

    // Fast Card & Scanner
    val cardCodeInput: String = "",
    val scannerNetwork: NetworkOperator = NetworkOperator.VODAFONE,
    val scannedCards: List<RechargeCard> = emptyList(),
    val isCameraModalOpen: Boolean = false,

    // Native Telephony & Stats (Free, No USSD)
    val mobileDataBytesToday: Long = 0L,
    val mobileDataBytesWeek: Long = 0L,
    val mobileDataBytesMonth: Long = 0L,
    val callUsage: CallUsageData = CallUsageData(),
    val sentSmsCount: Int = 0,
    val totalFlexesUsed: Int = 0,
    val lastStatsUpdateTime: String = "الآن",
    val isReadingNativeStats: Boolean = false,

    // Daily Limit & Bundle
    val dailyLimitMb: Int = 500,
    val isDailyLimitExceeded: Boolean = false,
    val userBundleName: String = "فليكس 45 (2000 فليكس)",
    val bundleTotalFlexes: Int = 2000,
    val bundleRemainingFlexes: Int = 1850,
    val bundleRemainingDays: Int = 18,

    // Calculators & Guides Dialogs
    val showNetTransferDialog: Boolean = false,
    val netTransferResult: NetTransferCalculation? = null,
    val showFlexCalculatorDialog: Boolean = false,
    val flexCalculatorResult: FlexConsumptionCalculation? = null,
    val showDailyLimitDialog: Boolean = false,
    val showFlexTransferGuideDialog: Boolean = false,
    val showUssdCompareDialog: Boolean = false,

    // Free Net filter
    val selectedFreeNetOperator: NetworkOperator? = null,
    val selectedFreeNetCategory: FreeNetCategory? = null,

    // Telecom Codes filter
    val selectedCodesOperator: NetworkOperator? = null,
    val selectedCodesCategory: ServiceCategory? = null,
    val codesSearchQuery: String = "",

    // Wallets & Cash Transfer
    val selectedWalletOperator: NetworkOperator = NetworkOperator.VODAFONE,
    val transferPhone: String = "",
    val transferAmount: String = "",

    // Modals
    val showEditNumberDialog: Boolean = false,
    val noticeMessage: String? = null
)

class KhedmatyViewModel(application: Application) : AndroidViewModel(application) {
    private val prefs = application.getSharedPreferences("khedmaty_prefs", Context.MODE_PRIVATE)
    private val db = AppDatabase.getDatabase(application)
    private val _uiState = MutableStateFlow(KhedmatyUiState())
    val uiState: StateFlow<KhedmatyUiState> = _uiState.asStateFlow()

    init {
        loadSimCards(application)
        loadSavedManualNumber()
        loadSavedPreferences()
        refreshNativeStats(application)
    }

    private fun loadSavedPreferences() {
        val savedLimit = prefs.getInt("daily_limit_mb", 500)
        val savedBundleName = prefs.getString("user_bundle_name", "فليكس 45 (2000 فليكس)") ?: "فليكس 45 (2000 فليكس)"
        val savedBundleTotal = prefs.getInt("user_bundle_total", 2000)
        val savedBundleDays = prefs.getInt("user_bundle_days", 18)

        _uiState.value = _uiState.value.copy(
            dailyLimitMb = savedLimit,
            userBundleName = savedBundleName,
            bundleTotalFlexes = savedBundleTotal,
            bundleRemainingDays = savedBundleDays
        )
    }

    private fun loadSavedManualNumber() {
        val saved = prefs.getString("user_custom_phone", null)
        if (!saved.isNullOrBlank()) {
            val detected = RealTelephonyService.detectOperatorFromNumber(saved)
            _uiState.value = _uiState.value.copy(
                activePhoneNumber = saved,
                activeOperator = detected,
                scannerNetwork = detected,
                selectedWalletOperator = detected
            )
        }
    }

    fun loadSimCards(context: Context) {
        val sims = RealTelephonyService.getInstalledSimCards(context)
        val isDual = sims.size > 1
        val currentIndex = _uiState.value.selectedSimIndex.coerceIn(0, (sims.size - 1).coerceAtLeast(0))
        val currentSim = sims.getOrNull(currentIndex) ?: sims.firstOrNull()
        val operator = currentSim?.detectedOperator ?: NetworkOperator.VODAFONE

        val savedSlotPhone = prefs.getString("sim_${currentIndex}_phone", null)
        val savedOperatorPhone = prefs.getString("operator_${operator.id}_phone", null)
        val genericSavedPhone = prefs.getString("user_custom_phone", null)
        val validGenericForOp = if (!genericSavedPhone.isNullOrBlank() && RealTelephonyService.detectOperatorFromNumber(genericSavedPhone) == operator) genericSavedPhone else null

        val phone = currentSim?.rawPhoneNumber
            ?: savedSlotPhone
            ?: savedOperatorPhone
            ?: validGenericForOp
            ?: when (operator) {
                NetworkOperator.ORANGE -> "012 (اضغط لإدخال رقم أورنج أو اطلب #119#)"
                NetworkOperator.ETISALAT -> "011 (اضغط لإدخال رقم اتصالات أو اطلب *947#)"
                NetworkOperator.WE -> "015 (اضغط لإدخال رقم وي أو اطلب *688#)"
                NetworkOperator.VODAFONE -> "010 (اضغط لإدخال رقم فودافون أو اطلب *878#)"
            }
        val carrier = currentSim?.carrierName ?: operator.titleArabic

        _uiState.value = _uiState.value.copy(
            installedSims = sims,
            isDualSimDevice = isDual,
            selectedSimIndex = currentIndex,
            activeOperator = operator,
            activePhoneNumber = phone,
            activeCarrierName = carrier,
            scannerNetwork = operator,
            selectedWalletOperator = operator
        )

        // Save SIM info in Room database asynchronously
        viewModelScope.launch(Dispatchers.IO) {
            sims.forEach { sim ->
                db.carrierDao().insertOrUpdateCarrier(
                    CarrierInfoEntity(
                        simSlotIndex = sim.slotIndex,
                        operatorId = sim.detectedOperator.id,
                        carrierName = sim.carrierName,
                        phoneNumber = sim.rawPhoneNumber ?: phone,
                        subscriptionId = sim.subscriptionId
                    )
                )
            }
        }
    }

    /**
     * Reads native telephony data, mobile data usage via NetworkStatsManager,
     * call minutes via CallLog, and SMS count without USSD fees.
     */
    fun refreshNativeStats(context: Context) {
        _uiState.value = _uiState.value.copy(isReadingNativeStats = true)

        viewModelScope.launch(Dispatchers.IO) {
            val now = System.currentTimeMillis()
            val startToday = NativeTelephonyStatsService.getStartOfTodayMs()
            val startWeek = NativeTelephonyStatsService.getStartOfWeekMs()
            val startMonth = NativeTelephonyStatsService.getStartOfMonthMs()

            // 1. Data usage
            val bytesToday = NativeTelephonyStatsService.getMobileDataUsageBytes(context, startToday, now)
            val bytesWeek = NativeTelephonyStatsService.getMobileDataUsageBytes(context, startWeek, now)
            val bytesMonth = NativeTelephonyStatsService.getMobileDataUsageBytes(context, startMonth, now)

            // 2. Call log usage
            val calls = NativeTelephonyStatsService.getCallUsageStats(context, startMonth, _uiState.value.activeOperator)

            // 3. Sent SMS count
            val sms = NativeTelephonyStatsService.getSentSmsCount(context, startMonth)

            // 4. Calculate flexes: 1 MB = 1 flex, calls flexes, 1 SMS = 1 flex
            val mbToday = (bytesToday / (1024 * 1024)).toInt()
            val totalFlexes = calls.estimatedFlexesFromCalls + mbToday + sms
            val remainingFlexes = (_uiState.value.bundleTotalFlexes - totalFlexes).coerceAtLeast(0)

            val timeFormat = SimpleDateFormat("h:mm a", Locale("ar"))
            val formattedTime = "اليوم ${timeFormat.format(Date())}"

            val isLimitExceeded = (bytesToday / (1024 * 1024)) > _uiState.value.dailyLimitMb

            // Store snapshot in Room
            val dateFormat = SimpleDateFormat("yyyy-MM-dd", Locale.US)
            val snapshot = UsageStatsSnapshotEntity(
                simSlotIndex = _uiState.value.selectedSimIndex,
                operatorId = _uiState.value.activeOperator.id,
                dateStr = dateFormat.format(Date()),
                timestamp = now,
                mobileDataBytesToday = bytesToday,
                mobileDataBytesWeek = bytesWeek,
                mobileDataBytesMonth = bytesMonth,
                callMinutesSameNet = calls.sameNetMinutes,
                callMinutesOtherNet = calls.otherNetMinutes,
                totalCallMinutes = calls.totalMinutes,
                smsCountSent = sms,
                estimatedFlexesUsed = totalFlexes,
                dailyLimitMb = _uiState.value.dailyLimitMb
            )
            db.usageStatsDao().insertSnapshot(snapshot)

            _uiState.value = _uiState.value.copy(
                mobileDataBytesToday = bytesToday,
                mobileDataBytesWeek = bytesWeek,
                mobileDataBytesMonth = bytesMonth,
                callUsage = calls,
                sentSmsCount = sms,
                totalFlexesUsed = totalFlexes,
                bundleRemainingFlexes = remainingFlexes,
                lastStatsUpdateTime = formattedTime,
                isReadingNativeStats = false,
                isDailyLimitExceeded = isLimitExceeded,
                noticeMessage = if (isLimitExceeded) "⚠️ تم تجاوز الحد اليومي لاستهلاك النت (${_uiState.value.dailyLimitMb} ميجا)!" else null
            )
        }
    }

    fun switchSim(index: Int) {
        val sims = _uiState.value.installedSims
        if (index in sims.indices) {
            val sim = sims[index]
            val op = sim.detectedOperator
            val savedSlotPhone = prefs.getString("sim_${index}_phone", null)
            val savedOperatorPhone = prefs.getString("operator_${op.id}_phone", null)
            val genericSavedPhone = prefs.getString("user_custom_phone", null)
            val validGenericForOp = if (!genericSavedPhone.isNullOrBlank() && RealTelephonyService.detectOperatorFromNumber(genericSavedPhone) == op) genericSavedPhone else null

            val phone = sim.rawPhoneNumber
                ?: savedSlotPhone
                ?: savedOperatorPhone
                ?: validGenericForOp
                ?: when (op) {
                    NetworkOperator.ORANGE -> "012 (اضغط لإدخال رقم أورنج أو اطلب #119#)"
                    NetworkOperator.ETISALAT -> "011 (اضغط لإدخال رقم اتصالات أو اطلب *947#)"
                    NetworkOperator.WE -> "015 (اضغط لإدخال رقم وي أو اطلب *688#)"
                    NetworkOperator.VODAFONE -> "010 (اضغط لإدخال رقم فودافون أو اطلب *878#)"
                }

            _uiState.value = _uiState.value.copy(
                selectedSimIndex = index,
                activeOperator = sim.detectedOperator,
                activePhoneNumber = phone,
                activeCarrierName = sim.carrierName,
                scannerNetwork = sim.detectedOperator,
                selectedFreeNetOperator = sim.detectedOperator,
                selectedWalletOperator = sim.detectedOperator,
                noticeMessage = "تم التبديل إلى: ${sim.displayName}"
            )
        }
    }

    fun setOperator(operator: NetworkOperator) {
        _uiState.value = _uiState.value.copy(
            activeOperator = operator,
            scannerNetwork = operator,
            selectedWalletOperator = operator,
            selectedFreeNetOperator = operator
        )
    }

    fun selectTab(tab: AppTab) {
        _uiState.value = _uiState.value.copy(currentTab = tab, noticeMessage = null)
    }

    fun updateCardCode(code: String) {
        _uiState.value = _uiState.value.copy(cardCodeInput = code)
    }

    fun onCodeScannedFromCamera(scannedPin: String) {
        val clean = CryptoManager.cleanOcrDigits(scannedPin)
        val masked = CryptoManager.maskPin(clean)
        val newCard = RechargeCard(
            network = _uiState.value.scannerNetwork,
            rawPin = clean,
            maskedPin = masked
        )
        val updated = listOf(newCard) + _uiState.value.scannedCards

        // Save in Room
        viewModelScope.launch(Dispatchers.IO) {
            db.rechargeHistoryDao().insertRecharge(
                RechargeHistoryEntity(
                    operatorId = _uiState.value.scannerNetwork.id,
                    maskedPin = masked,
                    isNetOnly = false
                )
            )
        }

        _uiState.value = _uiState.value.copy(
            cardCodeInput = clean,
            scannedCards = updated,
            isCameraModalOpen = false,
            noticeMessage = "✅ تم قراءة كود الكارت أوفلاين بنجاح!"
        )
    }

    fun processRechargeCard(rawPin: String) {
        val net = _uiState.value.scannerNetwork
        val validation = CryptoManager.validateCardPin(net, rawPin)
        if (!validation.isValid) {
            _uiState.value = _uiState.value.copy(
                noticeMessage = validation.errorReason ?: "كود الكارت غير صحيح"
            )
            return
        }
        val clean = validation.sanitizedPin
        val masked = CryptoManager.maskPin(clean)
        val newCard = RechargeCard(
            network = net,
            maskedPin = masked,
            rawPin = clean
        )
        val updated = listOf(newCard) + _uiState.value.scannedCards

        viewModelScope.launch(Dispatchers.IO) {
            db.rechargeHistoryDao().insertRecharge(
                RechargeHistoryEntity(
                    operatorId = net.id,
                    maskedPin = masked,
                    isNetOnly = false
                )
            )
        }

        _uiState.value = _uiState.value.copy(
            cardCodeInput = clean,
            scannedCards = updated,
            noticeMessage = "تم تجهيز الكود: $masked"
        )
    }

    fun saveManualPhoneNumber(phoneNumber: String) {
        val clean = RealTelephonyService.normalizeEgyptianPhoneNumber(phoneNumber) ?: phoneNumber.trim().replace(" ", "")
        val op = RealTelephonyService.detectOperatorFromNumber(clean)
        val slot = _uiState.value.selectedSimIndex
        prefs.edit()
            .putString("user_custom_phone", clean)
            .putString("sim_${slot}_phone", clean)
            .putString("operator_${op.id}_phone", clean)
            .apply()

        _uiState.value = _uiState.value.copy(
            activePhoneNumber = clean,
            activeOperator = op,
            scannerNetwork = op,
            selectedWalletOperator = op,
            showEditNumberDialog = false,
            noticeMessage = "تم حفظ الرقم بنجاح: $clean (${op.titleArabic})"
        )
    }

    fun setScannerNetwork(operator: NetworkOperator) {
        _uiState.value = _uiState.value.copy(scannerNetwork = operator)
    }

    fun setFreeNetFilter(operator: NetworkOperator?, category: FreeNetCategory?) {
        _uiState.value = _uiState.value.copy(
            selectedFreeNetOperator = operator,
            selectedFreeNetCategory = category
        )
    }

    fun setCodesFilter(operator: NetworkOperator?, category: ServiceCategory?, query: String) {
        _uiState.value = _uiState.value.copy(
            selectedCodesOperator = operator,
            selectedCodesCategory = category,
            codesSearchQuery = query
        )
    }

    fun updateTransferFields(operator: NetworkOperator, phone: String, amount: String) {
        _uiState.value = _uiState.value.copy(
            selectedWalletOperator = operator,
            transferPhone = phone,
            transferAmount = amount
        )
    }

    fun executeCashTransferUssd(context: Context) {
        val op = _uiState.value.selectedWalletOperator
        val phone = _uiState.value.transferPhone.trim()
        val amount = _uiState.value.transferAmount.trim()
        val dialCode = RealTelephonyService.formatCashTransferUssd(op, phone, amount)
        RealTelephonyService.dialUssd(context, dialCode)
        _uiState.value = _uiState.value.copy(
            noticeMessage = "طلب كود الخدمة: $dialCode"
        )
    }

    // Calculators
    fun calculateNetTransfer(amount: Double, recipientPhone: String) {
        val calc = NativeTelephonyStatsService.calculateNetTransfer(
            operator = _uiState.value.activeOperator,
            amount = amount,
            recipientPhone = recipientPhone
        )
        _uiState.value = _uiState.value.copy(
            netTransferResult = calc,
            showNetTransferDialog = true
        )
    }

    fun calculateFlexConsumption(sameMin: Int, otherMin: Int, mb: Int, sms: Int) {
        val result = NativeTelephonyStatsService.calculateFlexes(sameMin, otherMin, mb, sms)
        _uiState.value = _uiState.value.copy(
            flexCalculatorResult = result,
            showFlexCalculatorDialog = true
        )
    }

    fun setDailyLimit(limitMb: Int) {
        prefs.edit().putInt("daily_limit_mb", limitMb).apply()
        _uiState.value = _uiState.value.copy(
            dailyLimitMb = limitMb,
            showDailyLimitDialog = false,
            noticeMessage = "تم تعيين الحد اليومي: $limitMb ميجابايت"
        )
    }

    fun setBundleInfo(name: String, totalFlexes: Int, remainingDays: Int) {
        prefs.edit()
            .putString("user_bundle_name", name)
            .putInt("user_bundle_total", totalFlexes)
            .putInt("user_bundle_days", remainingDays)
            .apply()

        _uiState.value = _uiState.value.copy(
            userBundleName = name,
            bundleTotalFlexes = totalFlexes,
            bundleRemainingDays = remainingDays,
            bundleRemainingFlexes = (totalFlexes - _uiState.value.totalFlexesUsed).coerceAtLeast(0),
            noticeMessage = "تم تحديث بيانات الباقة: $name"
        )
    }

    // Dialog controls
    fun openNetTransferDialog() { _uiState.value = _uiState.value.copy(showNetTransferDialog = true) }
    fun closeNetTransferDialog() { _uiState.value = _uiState.value.copy(showNetTransferDialog = false) }

    fun openFlexCalculatorDialog() { _uiState.value = _uiState.value.copy(showFlexCalculatorDialog = true) }
    fun closeFlexCalculatorDialog() { _uiState.value = _uiState.value.copy(showFlexCalculatorDialog = false) }

    fun openDailyLimitDialog() { _uiState.value = _uiState.value.copy(showDailyLimitDialog = true) }
    fun closeDailyLimitDialog() { _uiState.value = _uiState.value.copy(showDailyLimitDialog = false) }

    fun openFlexTransferGuideDialog() { _uiState.value = _uiState.value.copy(showFlexTransferGuideDialog = true) }
    fun closeFlexTransferGuideDialog() { _uiState.value = _uiState.value.copy(showFlexTransferGuideDialog = false) }

    fun openUssdCompareDialog() { _uiState.value = _uiState.value.copy(showUssdCompareDialog = true) }
    fun closeUssdCompareDialog() { _uiState.value = _uiState.value.copy(showUssdCompareDialog = false) }

    fun openCameraModal() { _uiState.value = _uiState.value.copy(isCameraModalOpen = true) }
    fun closeCameraModal() { _uiState.value = _uiState.value.copy(isCameraModalOpen = false) }

    fun openEditNumberDialog() { _uiState.value = _uiState.value.copy(showEditNumberDialog = true) }
    fun closeEditNumberDialog() { _uiState.value = _uiState.value.copy(showEditNumberDialog = false) }

    fun clearNotice() { _uiState.value = _uiState.value.copy(noticeMessage = null) }
}
