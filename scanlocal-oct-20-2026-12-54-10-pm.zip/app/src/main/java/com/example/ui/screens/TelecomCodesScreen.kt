package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkOperator
import com.example.model.ServiceCategory
import com.example.model.TelecomCodesCatalog
import com.example.model.TelecomServiceCode
import com.example.service.RealTelephonyService
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.RoyalBlueLight
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.KhedmatyUiState

@Composable
fun TelecomCodesScreen(
    uiState: KhedmatyUiState,
    onFilterChange: (NetworkOperator?, ServiceCategory?, String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val filteredList = TelecomCodesCatalog.allCodes.filter { codeItem ->
        val matchesOp = uiState.selectedCodesOperator == null ||
                codeItem.network == uiState.selectedCodesOperator ||
                codeItem.network == null
        val matchesCat = uiState.selectedCodesCategory == null ||
                codeItem.category == uiState.selectedCodesCategory
        val matchesQuery = uiState.codesSearchQuery.isBlank() ||
                codeItem.serviceName.contains(uiState.codesSearchQuery, ignoreCase = true) ||
                codeItem.ussdCode.contains(uiState.codesSearchQuery, ignoreCase = true)
        matchesOp && matchesCat && matchesQuery
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Banner
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF1E3A8A).copy(alpha = 0.4f),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E40AF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(RoyalBlueLight.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = RoyalBlueLight, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "دليل الأكواد الشامل (العريف)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFBFDBFE)
                        )
                        Text(
                            text = "أكواد تحويل الرصيد والمكالمات وإلغاء الخدمات والكول تون",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        // Search Bar
        item {
            OutlinedTextField(
                value = uiState.codesSearchQuery,
                onValueChange = {
                    onFilterChange(uiState.selectedCodesOperator, uiState.selectedCodesCategory, it)
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("telecom_search_input"),
                placeholder = { Text("ابحث عن أي خدمة أو كود...", color = TextDim, fontSize = 12.sp) },
                leadingIcon = {
                    Icon(Icons.Default.Search, contentDescription = null, tint = GoldPrimary)
                },
                singleLine = true,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = GoldPrimary,
                    unfocusedBorderColor = NavyCardBorder,
                    focusedTextColor = TextWhite,
                    unfocusedTextColor = TextWhite,
                    focusedContainerColor = NavySurface,
                    unfocusedContainerColor = NavySurface
                ),
                shape = RoundedCornerShape(14.dp)
            )
        }

        // Operator Filters
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    val isAll = uiState.selectedCodesOperator == null
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isAll) GoldPrimary else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isAll) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onFilterChange(null, uiState.selectedCodesCategory, uiState.codesSearchQuery) }
                    ) {
                        Text(
                            text = "الكل",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAll) NavyDark else TextWhite,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
                items(NetworkOperator.values()) { op ->
                    val isSelected = uiState.selectedCodesOperator == op
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) op.brandColor else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onFilterChange(op, uiState.selectedCodesCategory, uiState.codesSearchQuery) }
                    ) {
                        Text(
                            text = op.titleArabic,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else TextWhite,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp)
                        )
                    }
                }
            }
        }

        // Category Filters
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    val isAll = uiState.selectedCodesCategory == null
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isAll) NavySurfaceVariant else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isAll) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onFilterChange(uiState.selectedCodesOperator, null, uiState.codesSearchQuery) }
                    ) {
                        Text(
                            text = "جميع الأقسام",
                            fontSize = 11.sp,
                            color = if (isAll) GoldPrimary else TextMuted,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
                items(ServiceCategory.values()) { cat ->
                    val isSelected = uiState.selectedCodesCategory == cat
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (isSelected) NavySurfaceVariant else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(8.dp))
                            .clickable { onFilterChange(uiState.selectedCodesOperator, cat, uiState.codesSearchQuery) }
                    ) {
                        Text(
                            text = cat.titleArabic,
                            fontSize = 11.sp,
                            color = if (isSelected) GoldPrimary else TextMuted,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            }
        }

        // Items
        items(filteredList) { item ->
            val brandColor = item.network?.brandColor ?: GoldPrimary
            val networkName = item.network?.titleArabic ?: "كود عام (لكل الشبكات)"

            val isEtisalatGift = item.ussdCode == "*890#"

            Surface(
                color = if (isEtisalatGift) NavySurfaceVariant else NavySurface,
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(
                    if (isEtisalatGift) 1.5.dp else 1.dp,
                    if (isEtisalatGift) GoldPrimary else NavyCardBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(brandColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = networkName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = brandColor
                            )
                            if (item.ussdCode == "*890#") {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = Color(0xFF22C55E)
                                ) {
                                    Text(
                                        text = "⭐ مميز 2 جيجا",
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = Color.Black,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            } else if (item.network == NetworkOperator.ORANGE || item.network == NetworkOperator.ETISALAT) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(4.dp),
                                    color = NavyDark
                                ) {
                                    Text(
                                        text = "كود أساسي",
                                        fontSize = 9.sp,
                                        color = GoldLight,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Text(
                            text = item.category.titleArabic,
                            fontSize = 10.sp,
                            color = TextMuted
                        )
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = item.serviceName,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )

                    if (item.note.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(text = item.note, fontSize = 11.sp, color = TextMuted)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = NavyDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = item.ussdCode,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldLight
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = { RealTelephonyService.copyToClipboard(context, item.ussdCode) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", tint = TextMuted, modifier = Modifier.size(16.dp))
                                }
                                Button(
                                    onClick = { RealTelephonyService.dialUssd(context, item.ussdCode) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(containerColor = brandColor, contentColor = Color.White),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("اتصال", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
