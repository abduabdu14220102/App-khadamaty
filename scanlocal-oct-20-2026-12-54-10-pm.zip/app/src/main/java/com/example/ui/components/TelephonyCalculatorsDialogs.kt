package com.example.ui.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Calculate
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhoneForwarded
import androidx.compose.material.icons.filled.Poll
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.model.NetworkOperator
import com.example.service.NativeTelephonyStatsService
import com.example.service.RealTelephonyService
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WarningOrange

/**
 * Net Balance Transfer Calculator Dialog (حاسبة صافي تحويل الرصيد)
 * Calculates transfer fee, taxes, exact amount deducted, and recipient's net received.
 */
@Composable
fun NetTransferCalculatorDialog(
    currentOperator: NetworkOperator,
    onDismiss: () -> Unit,
    onExecuteDial: (ussdCode: String) -> Unit
) {
    var recipientPhone by remember { mutableStateOf("") }
    var transferAmount by remember { mutableStateOf("10") }

    val amountDouble = transferAmount.toDoubleOrNull() ?: 0.0
    val calc = remember(currentOperator, amountDouble, recipientPhone) {
        if (amountDouble > 0) {
            NativeTelephonyStatsService.calculateNetTransfer(currentOperator, amountDouble, recipientPhone)
        } else null
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NavySurface,
            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                    }
                    Text(
                        text = "حاسبة صافي تحويل الرصيد",
                        color = GoldPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(currentOperator.brandColor.copy(alpha = 0.2f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Calculate, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Operator Badge
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = currentOperator.brandColor.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, currentOperator.brandColor.copy(alpha = 0.4f))
                ) {
                    Text(
                        text = "الشبكة المحددة: ${currentOperator.titleArabic}",
                        color = Color.White,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                    )
                }

                Spacer(modifier = Modifier.height(14.dp))

                OutlinedTextField(
                    value = recipientPhone,
                    onValueChange = { recipientPhone = it },
                    label = { Text("رقم المستلم (01xxxxxxxxx)", color = TextMuted, fontSize = 12.sp) },
                    placeholder = { Text("01xxxxxxxxx", color = TextMuted.copy(alpha = 0.5f)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldPrimary.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(10.dp))

                OutlinedTextField(
                    value = transferAmount,
                    onValueChange = { transferAmount = it },
                    label = { Text("مبلغ التحويل بالجنيه", color = TextMuted, fontSize = 12.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldPrimary.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp)
                )

                Spacer(modifier = Modifier.height(16.dp))

                // Breakdown Results Box
                if (calc != null) {
                    Surface(
                        shape = RoundedCornerShape(14.dp),
                        color = NavyDark,
                        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.25f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("المبلغ المطلوب تحويله:", color = TextMuted, fontSize = 13.sp)
                                Text("${calc.amount} ج.م", color = TextWhite, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("رسوم وضريبة التحويل:", color = TextMuted, fontSize = 13.sp)
                                Text(String.format(java.util.Locale.US, "%.2f ج.م", calc.transferFeeEgp), color = GoldAccent, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("إجمالي الخصم من رصيدك:", color = GoldPrimary, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text(String.format(java.util.Locale.US, "%.2f ج.م", calc.totalDeductedEgp), color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text("الصافي الواصل للمستلم:", color = SuccessGreen, fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                Text("${calc.netReceivedEgp} ج.م صافي", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Text(
                                text = "ℹ️ ${calc.ruleExplanationArabic}",
                                color = TextMuted,
                                fontSize = 11.sp,
                                textAlign = TextAlign.Center,
                                modifier = Modifier.fillMaxWidth()
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = { onExecuteDial(calc.formattedConfirmationUssd) },
                        colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                    ) {
                        Icon(Icons.Default.PhoneForwarded, contentDescription = null, tint = NavyDark)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("تأكيد وطلب التحويل بأمان", color = NavyDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                    }
                }
            }
        }
    }
}

/**
 * Flexes & Megabytes Consumption Calculator Dialog (حاسبة استهلاك الفلكسات الذكية)
 */
@Composable
fun FlexCalculatorDialog(
    onDismiss: () -> Unit
) {
    var sameMin by remember { mutableStateOf("20") }
    var otherMin by remember { mutableStateOf("5") }
    var megabytes by remember { mutableStateOf("150") }
    var smsCount by remember { mutableStateOf("2") }

    val calc = remember(sameMin, otherMin, megabytes, smsCount) {
        val s = sameMin.toIntOrNull() ?: 0
        val o = otherMin.toIntOrNull() ?: 0
        val mb = megabytes.toIntOrNull() ?: 0
        val sms = smsCount.toIntOrNull() ?: 0
        NativeTelephonyStatsService.calculateFlexes(s, o, mb, sms)
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NavySurface,
            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                    }
                    Text(
                        text = "حاسبة الفلكسات الذكية",
                        color = GoldPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(GoldPrimary.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "احسب الفلكسات المستهلكة من الباقة وفقاً للسياسات الرسمية لشركات الاتصالات:",
                    color = TextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = sameMin,
                    onValueChange = { sameMin = it },
                    label = { Text("دقائق لنفس الشبكة (1 دقيقة = 1 فليكس)", color = TextMuted, fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldPrimary.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = otherMin,
                    onValueChange = { otherMin = it },
                    label = { Text("دقائق للشبكات الأخرى (1 دقيقة = 5 فليكس)", color = TextMuted, fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldPrimary.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = megabytes,
                    onValueChange = { megabytes = it },
                    label = { Text("ميجابايت تصفح ونت (1 ميجا = 1 فليكس)", color = TextMuted, fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldPrimary.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(8.dp))

                OutlinedTextField(
                    value = smsCount,
                    onValueChange = { smsCount = it },
                    label = { Text("عدد الرسائل SMS (1 رسالة = 1 فليكس)", color = TextMuted, fontSize = 11.sp) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = GoldPrimary,
                        unfocusedBorderColor = GoldPrimary.copy(alpha = 0.3f),
                        focusedTextColor = TextWhite,
                        unfocusedTextColor = TextWhite
                    ),
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Spacer(modifier = Modifier.height(14.dp))

                // Result Box
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = NavyDark,
                    border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text("إجمالي الفلكسات المطلوبة:", color = TextMuted, fontSize = 13.sp)
                        Text(
                            text = "${calc.totalFlexesRequired} فليكس",
                            color = GoldPrimary,
                            fontWeight = FontWeight.ExtraBold,
                            fontSize = 26.sp
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = calc.breakdownArabic,
                            color = TextMuted,
                            fontSize = 11.sp,
                            textAlign = TextAlign.Center
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Text("تم", color = NavyDark, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

/**
 * Daily Limit Selector Dialog (محدد الحد الأقصى اليومي)
 */
@Composable
fun DailyLimitDialog(
    currentLimitMb: Int,
    onSaveLimit: (Int) -> Unit,
    onDismiss: () -> Unit
) {
    var selectedMb by remember { mutableStateOf(currentLimitMb) }
    val options = listOf(200, 500, 1000, 2000, 5000)

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NavySurface,
            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                    }
                    Text(
                        text = "الحد الأقصى اليومي للبيانات",
                        color = GoldPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(GoldPrimary.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.NotificationsActive, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                Text(
                    text = "سيقوم التطبيق بتنبيهك تلقائياً وبشكل مجاني (أوفلاين) عندما يتجاوز استهلاك بيانات الشريحة هذا الحد اليومي:",
                    color = TextMuted,
                    fontSize = 12.sp,
                    textAlign = TextAlign.Center
                )

                Spacer(modifier = Modifier.height(16.dp))

                options.forEach { mb ->
                    val isSelected = selectedMb == mb
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) GoldPrimary.copy(alpha = 0.2f) else NavyDark,
                        border = BorderStroke(1.dp, if (isSelected) GoldPrimary else Color.Transparent),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                            .clickable { selectedMb = mb }
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 16.dp, vertical = 12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (mb >= 1000) "${mb / 1000} جيجابايت / يوم" else "$mb ميجابايت / يوم",
                                color = if (isSelected) GoldPrimary else TextWhite,
                                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                            if (isSelected) {
                                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onSaveLimit(selectedMb) },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Text("حفظ وتفعيل التنبيه", color = NavyDark, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            }
        }
    }
}

/**
 * Flexes Transfer Guide Dialog (دليل تحويل الفلكسات)
 */
@Composable
fun FlexTransferGuideDialog(
    currentOperator: NetworkOperator,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NavySurface,
            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                    }
                    Text(
                        text = "دليل تحويل الفلكسات والميجابايت",
                        color = GoldPrimary,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(GoldPrimary.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Operator specific cards
                when (currentOperator) {
                    NetworkOperator.VODAFONE -> {
                        GuideItem(
                            title = "تحويل فليكسات فودافون",
                            code = "*868*2*الرقم*الفلكسات#",
                            details = "الحد الأقصى للتحويل 250 فليكس لكل رقم. الرسوم: 50 فليكس = 50 قرش، 100 فليكس = 1 جنيه، 150 فليكس = 1.5 جنيه، 200 فليكس = 2 جنيه، 250 فليكس = 2.5 جنيه.",
                            onDial = { RealTelephonyService.dialUssd(context, "*868*2#") }
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        GuideItem(
                            title = "معرفة الفليكسات المستلمة والمحولة",
                            code = "*868*60#",
                            details = "استعلام عن الفليكسات المحولة والمستلمة وصلاحيتها مجاناً.",
                            onDial = { RealTelephonyService.dialUssd(context, "*868*60#") }
                        )
                    }
                    NetworkOperator.ORANGE -> {
                        GuideItem(
                            title = "تحويل وحدات وميجابايتس أورنج",
                            code = "#100*4#",
                            details = "كود أساسي: اطلب #100*4# لاختيار تحويل الميجابايتس أو الدقائق لأي خط أورنج آخر.",
                            onDial = { RealTelephonyService.dialUssd(context, "#100*4#") }
                        )
                    }
                    NetworkOperator.ETISALAT -> {
                        GuideItem(
                            title = "تحويل ميكسات اتصالات (حكاية)",
                            code = "*770#",
                            details = "كود أساسي: اطلب *770# ثم اتبع القائمة لتحويل الميكسات أو الرصيد للأرقام الأخرى في العائلة.",
                            onDial = { RealTelephonyService.dialUssd(context, "*770#") }
                        )
                    }
                    NetworkOperator.WE -> {
                        GuideItem(
                            title = "تحويل وحدات وميجابايتس وي (WE)",
                            code = "*551#",
                            details = "اطلب *551# ثم اختر تحويل الوحدات أو الرصيد المتاح من الباقة.",
                            onDial = { RealTelephonyService.dialUssd(context, "*551#") }
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = onDismiss,
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().height(44.dp)
                ) {
                    Text("حسناً", color = NavyDark, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
private fun GuideItem(
    title: String,
    code: String,
    details: String,
    onDial: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = NavyDark,
        border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.25f)),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Text(title, color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 14.sp)
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(6.dp),
                color = NavySurfaceVariant
            ) {
                Text(
                    text = code,
                    color = TextWhite,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                )
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(details, color = TextMuted, fontSize = 12.sp)
            Spacer(modifier = Modifier.height(8.dp))
            Button(
                onClick = onDial,
                colors = ButtonDefaults.buttonColors(containerColor = GoldAccent.copy(alpha = 0.2f)),
                shape = RoundedCornerShape(8.dp),
                modifier = Modifier.fillMaxWidth().height(36.dp)
            ) {
                Text("طلب الكود", color = GoldPrimary, fontSize = 12.sp, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * USSD Comparison Dialog (مقارنة القراءة المباشرة مع USSD)
 * Explains that native readings are free and offers optional USSD verification with fee disclosure.
 */
@Composable
fun UssdCompareDialog(
    currentOperator: NetworkOperator,
    onDismiss: () -> Unit,
    onDialUssd: (String) -> Unit
) {
    val ussdCode = currentOperator.ussdBalanceCode
    val costNotice = when (currentOperator) {
        NetworkOperator.VODAFONE -> "ملاحظة: كود *868*1# يخصم 19 قرشاً في حالة عدم وجود فلكسات كافية."
        NetworkOperator.ORANGE -> "ملاحظة: كود #100# قد يظهر قوائم تفاعلية على الشاشة."
        NetworkOperator.ETISALAT -> "ملاحظة: كود *555# قد يخصم رسوم استعلام بسيطة بعد المرة الأولى."
        NetworkOperator.WE -> "ملاحظة: كود *550# يخصم 5 قروش للاستعلام."
    }

    Dialog(onDismissRequest = onDismiss) {
        Surface(
            shape = RoundedCornerShape(20.dp),
            color = NavySurface,
            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier
                    .padding(20.dp)
                    .verticalScroll(rememberScrollState()),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = onDismiss, modifier = Modifier.size(36.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = TextMuted)
                    }
                    Text(
                        text = "مقارنة القراءة مع كود الاستعلام",
                        color = GoldPrimary,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Box(
                        modifier = Modifier
                            .size(36.dp)
                            .background(GoldPrimary.copy(alpha = 0.15f), CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Poll, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(20.dp))
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Comparison Box 1: Native Reading
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NavyDark,
                    border = BorderStroke(1.dp, SuccessGreen.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("1. القراءة المباشرة من النظام", color = SuccessGreen, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = SuccessGreen.copy(alpha = 0.2f)
                            ) {
                                Text("مجاناً 100%", color = SuccessGreen, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "تعتمد على NetworkStatsManager و CallLog و Telephony APIs الرسمية من أندرويد. تعمل أوفلاين بدون إنترنت وبدون خصم مليم واحد.",
                            color = TextWhite,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Comparison Box 2: Service Code
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = NavyDark,
                    border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.35f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("2. كود الاستعلام السريع ($ussdCode)", color = GoldPrimary, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = WarningOrange.copy(alpha = 0.2f)
                            ) {
                                Text("قد يخصم رسوماً", color = WarningOrange, fontSize = 10.sp, fontWeight = FontWeight.Bold, modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp))
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = costNotice,
                            color = TextMuted,
                            fontSize = 11.sp
                        )
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                Button(
                    onClick = { onDialUssd(ussdCode) },
                    colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier.fillMaxWidth().height(48.dp)
                ) {
                    Icon(Icons.Default.Phone, contentDescription = null, tint = NavyDark)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("طلب كود الاستعلام الآن ($ussdCode)", color = NavyDark, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                }

                Spacer(modifier = Modifier.height(8.dp))

                TextButton(onClick = onDismiss) {
                    Text("إغلاق والاعتماد على القراءة المجانية", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
    }
}
