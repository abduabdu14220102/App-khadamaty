package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkOperator
import com.example.service.RealTelephonyService
import com.example.service.WalletShortcutCode
import com.example.ui.components.AdBannerCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.KhedmatyUiState

@Composable
fun WalletsScreen(
    uiState: KhedmatyUiState,
    onUpdateFields: (NetworkOperator, String, String) -> Unit,
    onExecuteTransferUssd: (Context) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val currentOperator = uiState.selectedWalletOperator
    val walletShortcuts = RealTelephonyService.getWalletShortcuts(currentOperator)
    val transferUssdCode = RealTelephonyService.formatCashTransferUssd(
        currentOperator,
        uiState.transferPhone,
        uiState.transferAmount
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Banner
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    Brush.horizontalGradient(listOf(GoldPrimary, currentOperator.brandColor, GoldAccent))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("wallet_shortcuts_header")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(currentOperator.brandColor.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AccountBalanceWallet,
                                contentDescription = null,
                                tint = currentOperator.brandColor,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "محفظة الكاش (${currentOperator.titleArabic})",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                            Text(
                                text = "تحويل واستعلام أموال بأكواد الخدمة المباشرة",
                                fontSize = 11.sp,
                                color = GoldLight
                            )
                        }
                    }
                }
            }
        }

        // 2. Network Switcher Pills
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NetworkOperator.values().forEach { op ->
                    val isSelected = currentOperator == op
                    val opWalletName = when (op) {
                        NetworkOperator.VODAFONE -> "فودافون كاش"
                        NetworkOperator.ORANGE -> "أورنج كاش"
                        NetworkOperator.ETISALAT -> "اتصالات كاش"
                        NetworkOperator.WE -> "وي باي"
                    }
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) op.brandColor else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) GoldPrimary else NavyCardBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable {
                                onUpdateFields(op, uiState.transferPhone, uiState.transferAmount)
                            }
                            .testTag("wallet_op_${op.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp, horizontal = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = opWalletName,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else TextWhite
                            )
                        }
                    }
                }
            }
        }

        // 3. View Cash Balance Button
        item {
            Button(
                onClick = { RealTelephonyService.dialUssd(context, currentOperator.ussdCashBalanceCode) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = GoldPrimary,
                    contentColor = NavyDark
                ),
                shape = RoundedCornerShape(14.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("btn_view_cash_balance")
            ) {
                Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(18.dp))
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = "عرض الرصيد الكاش (${currentOperator.titleArabic}: ${currentOperator.ussdCashBalanceCode})",
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold
                )
            }
        }

        // 4. Direct USSD Cash Transfer Builder
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, currentOperator.brandColor.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "تحويل أموال الكاش:",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = currentOperator.brandColor
                        ) {
                            Text(
                                text = currentOperator.titleArabic,
                                fontSize = 10.sp,
                                color = Color.White,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "رقم المحول إليه:", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = uiState.transferPhone,
                        onValueChange = { onUpdateFields(currentOperator, it, uiState.transferAmount) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("wallet_phone_input"),
                        placeholder = { Text("01xxxxxxxxx", color = TextDim) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(text = "المبلغ (جنيه):", fontSize = 11.sp, color = TextMuted)
                    Spacer(modifier = Modifier.height(4.dp))
                    OutlinedTextField(
                        value = uiState.transferAmount,
                        onValueChange = { onUpdateFields(currentOperator, uiState.transferPhone, it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("wallet_amount_input"),
                        placeholder = { Text("مثلاً 100", color = TextDim) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )

                    if (currentOperator == NetworkOperator.ORANGE || currentOperator == NetworkOperator.ETISALAT) {
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = currentOperator.brandColor.copy(alpha = 0.15f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, currentOperator.brandColor.copy(alpha = 0.4f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text(
                                text = "ℹ️ تنبيه: شبكة ${currentOperator.titleArabic} تدعم الأكواد الأساسية فقط (${if (currentOperator == NetworkOperator.ORANGE) "#115#" else "*777#"}) بدون اختصارات فرعية. سيتم فتح القائمة التفاعلية لتأكيد التحويل مباشرة.",
                                fontSize = 11.sp,
                                color = GoldLight,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NavyDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (currentOperator == NetworkOperator.ORANGE || currentOperator == NetworkOperator.ETISALAT) "الكود الأساسي المعتمد:" else "كود الاتصال التلقائي:",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                                Text(
                                    text = transferUssdCode,
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = GoldLight,
                                    letterSpacing = 0.5.sp
                                )
                            }
                            IconButton(
                                onClick = {
                                    RealTelephonyService.copyToClipboard(context, transferUssdCode)
                                },
                                modifier = Modifier.size(32.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = "نسخ الكود", tint = GoldPrimary, modifier = Modifier.size(16.dp))
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Button(
                        onClick = {
                            onExecuteTransferUssd(context)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = currentOperator.brandColor,
                            contentColor = Color.White
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(46.dp)
                            .testTag("execute_cash_transfer_button")
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (currentOperator == NetworkOperator.ORANGE || currentOperator == NetworkOperator.ETISALAT) {
                                "طلب الكود الأساسي ($transferUssdCode)"
                            } else {
                                "تحويل الآن ($transferUssdCode)"
                            },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }

        // 5. Wallet Shortcuts Directory
        item {
            Text(
                text = "خدمات وأكواد محفظة ${currentOperator.titleArabic}:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )
        }

        items(walletShortcuts) { shortcut ->
            Surface(
                color = NavySurface,
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(
                    1.dp,
                    if (shortcut.isPrimary) shortcut.operator.brandColor.copy(alpha = 0.5f) else NavyCardBorder
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = shortcut.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = shortcut.description,
                        fontSize = 11.sp,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = NavyDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = shortcut.ussdCode,
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = GoldLight
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = { RealTelephonyService.copyToClipboard(context, shortcut.ussdCode) },
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", tint = TextMuted, modifier = Modifier.size(16.dp))
                                }
                                Button(
                                    onClick = { RealTelephonyService.dialUssd(context, shortcut.ussdCode) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = shortcut.operator.brandColor,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.height(30.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(12.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("اتصال", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            AdBannerCard()
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
