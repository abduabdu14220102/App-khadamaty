package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Luxury Royal Navy & Egyptian Gold Theme
val NavyDark = Color(0xFF0F172A) // Tailwind Slate 900 / dark bg matching HTML
val NavySurface = Color(0xFF1E293B) // Slate 800
val NavySurfaceVariant = Color(0xFF334155) // Slate 700
val NavyCardBorder = Color(0xFF475569) // Slate 600
val RoyalBluePrimary = Color(0xFF2563EB) // Blue 600
val RoyalBlueLight = Color(0xFF3B82F6) // Blue 500
val GoldPrimary = Color(0xFFFBBF24) // Yellow 400
val GoldAccent = Color(0xFFF59E0B) // Amber 500
val GoldLight = Color(0xFFFEF08A) // Yellow 200
val SuccessGreen = Color(0xFF16A34A) // Green 600
val WarningOrange = Color(0xFFF59E0B) // Amber 500
val ErrorRed = Color(0xFFEF4444) // Red 500 matching HTML roi-overlay

// Egyptian Mobile Telecom Operator Brand Colors
val VodafoneRed = Color(0xFFDC2626) // Red 600
val OrangeEgypt = Color(0xFFEA580C) // Orange 600
val EtisalatGreen = Color(0xFF15803D) // Green 700
val WePurple = Color(0xFF6B21A8) // Purple 800

val TextWhite = Color(0xFFF8FAFC)
val TextMuted = Color(0xFF94A3B8)
val TextDim = Color(0xFF64748B)
