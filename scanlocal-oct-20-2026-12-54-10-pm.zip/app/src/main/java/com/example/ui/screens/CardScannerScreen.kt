package com.example.ui.screens

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkOperator
import com.example.security.CryptoManager
import com.example.service.RealTelephonyService
import com.example.ui.components.AdBannerCard
import com.example.ui.components.CameraCardScanner
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.KhedmatyUiState

@Composable
fun CardScannerScreen(
    uiState: KhedmatyUiState,
    onSelectNetwork: (NetworkOperator) -> Unit,
    onProcessCard: (String) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var pinInput by remember { mutableStateOf("") }
    var isDetectedByCamera by remember { mutableStateOf(false) }

    val demoPins = when (uiState.scannerNetwork) {
        NetworkOperator.VODAFONE -> listOf("7894 1234 5678 90", "8521 9632 7412 5812")
        NetworkOperator.ORANGE -> listOf("4561 2378 9012 34", "9874 5612 3012 8901")
        NetworkOperator.ETISALAT -> listOf("12345 67890 12345", "9876 5432 1098 7654")
        NetworkOperator.WE -> listOf("9876 5432 1098 76", "1122 3344 5566 7788")
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Operator Selection
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Text(
                text = "اختر شبكة الكارت للمسح المباشر (14 إلى 16 رقماً):",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                NetworkOperator.values().forEach { op ->
                    val isSelected = uiState.scannerNetwork == op
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) op.brandColor else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (isSelected) GoldPrimary else NavyCardBorder
                        ),
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onSelectNetwork(op) }
                            .testTag("scanner_op_${op.id}")
                    ) {
                        Column(
                            modifier = Modifier.padding(vertical = 10.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text(
                                text = op.titleArabic,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                            Text(
                                text = "14 - 16 رقم",
                                fontSize = 10.sp,
                                color = if (isSelected) GoldLight else TextMuted
                            )
                        }
                    }
                }
            }
        }

        // 2. Live High-Accuracy ROI CameraX Scanner
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "قارئ كارت الشحن (OCR):",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFFEF4444).copy(alpha = 0.2f)
                ) {
                    Text(
                        text = "منطقة المستطيل الأحمر",
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color(0xFFEF4444),
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            CameraCardScanner(
                targetOperator = uiState.scannerNetwork,
                onPinDetected = { scannedPin ->
                    pinInput = scannedPin
                    isDetectedByCamera = true
                    onProcessCard(scannedPin)
                }
            )
        }

        // 3. Instant Recharge Action Hub (Dual Modes from HTML app)
        if (pinInput.isNotBlank()) {
            item {
                Surface(
                    shape = RoundedCornerShape(18.dp),
                    color = uiState.scannerNetwork.brandColor.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, uiState.scannerNetwork.brandColor),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = if (isDetectedByCamera) "تم القراءة بالكاميرا بنجاح:" else "كود الكارت المحدد:",
                                    fontSize = 11.sp,
                                    color = GoldLight,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    text = CryptoManager.maskPin(pinInput),
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.ExtraBold,
                                    color = TextWhite,
                                    letterSpacing = 1.sp
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = uiState.scannerNetwork.brandColor
                            ) {
                                Text(
                                    text = uiState.scannerNetwork.titleArabic,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color.White,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))
                        val clean = CryptoManager.cleanOcrDigits(pinInput)
                        val normalRechargeUssd = RealTelephonyService.formatRechargeUssd(uiState.scannerNetwork, clean, isNetOnly = false)
                        val netRechargeUssd = RealTelephonyService.formatRechargeUssd(uiState.scannerNetwork, clean, isNetOnly = true)

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    RealTelephonyService.dialUssd(context, normalRechargeUssd)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = uiState.scannerNetwork.brandColor,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("scanner_btn_recharge_regular")
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = uiState.scannerNetwork.rechargeLabel,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }

                            Button(
                                onClick = {
                                    RealTelephonyService.dialUssd(context, netRechargeUssd)
                                },
                                shape = RoundedCornerShape(12.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = SuccessGreen,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(48.dp)
                                    .testTag("scanner_btn_recharge_net")
                            ) {
                                Icon(Icons.Default.Wifi, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "شحن إنترنت فقط",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = {
                                    RealTelephonyService.copyToClipboard(context, clean, "تم نسخ كود الكارت: $clean")
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NavyDark,
                                    contentColor = TextWhite
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                            ) {
                                Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("نسخ الرقم", fontSize = 11.sp)
                            }

                            Button(
                                onClick = {
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "text/plain"
                                        putExtra(Intent.EXTRA_SUBJECT, "كود كارت ${uiState.scannerNetwork.titleArabic}")
                                        putExtra(
                                            Intent.EXTRA_TEXT,
                                            "كود شحن ${uiState.scannerNetwork.titleArabic}:\nالرقم: $clean\nكود الشحن المباشر: $normalRechargeUssd"
                                        )
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة كود الكارت"))
                                },
                                shape = RoundedCornerShape(10.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = NavyDark,
                                    contentColor = TextWhite
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .height(38.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("مشاركة", fontSize = 11.sp)
                            }
                        }
                    }
                }
            }
        }

        // 4. Manual Pin Input & Presets
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "أو أدخل كود الكارت يدوياً:",
                        style = MaterialTheme.typography.bodySmall,
                        color = TextMuted
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    OutlinedTextField(
                        value = pinInput,
                        onValueChange = {
                            pinInput = it
                            isDetectedByCamera = false
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("scanner_pin_input"),
                        placeholder = { Text(uiState.scannerNetwork.codePattern, color = TextDim) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = GoldPrimary,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        )
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text(
                        text = "أكواد تجريبية سريعة:",
                        fontSize = 11.sp,
                        color = GoldLight
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(demoPins) { pin ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = NavySurfaceVariant,
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .clickable {
                                        pinInput = pin
                                        onProcessCard(pin)
                                    }
                            ) {
                                Text(
                                    text = pin,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // 5. Sponsored Ad Banner
        item {
            AdBannerCard()
        }

        // 6. Scanned Cards History
        if (uiState.scannedCards.isNotEmpty()) {
            item {
                Text(
                    text = "سجل الكروت الممسوحة:",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
            }
            items(uiState.scannedCards) { card ->
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, card.network.brandColor.copy(alpha = 0.5f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(14.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                text = "كارت ${card.network.titleArabic}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = card.network.brandColor
                            )
                            Text(
                                text = card.maskedPin,
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        }
                        Button(
                            onClick = {
                                val ussd = RealTelephonyService.formatRechargeUssd(card.network, card.rawPin, false)
                                RealTelephonyService.dialUssd(context, ussd)
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = card.network.brandColor,
                                contentColor = Color.White
                            ),
                            modifier = Modifier.height(34.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(13.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("شحن", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
