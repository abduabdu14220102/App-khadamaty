package com.example.ui.components

import android.content.Context
import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalOffer
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.service.RealTelephonyService
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.RoyalBlueLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

data class PromoAd(
    val id: String,
    val sponsorName: String,
    val title: String,
    val description: String,
    val callToAction: String,
    val highlightColor: Color = GoldPrimary,
    val ussdAction: String? = null
)

val DEFAULT_PROMO_ADS = listOf(
    PromoAd(
        id = "ad_super_mega",
        sponsorName = "باقة سوبر ميجا",
        title = "ضعف الباقة عند الشحن السريع",
        description = "احصل على حتى 10,000 ميجابايتس إضافية عند شحن كارت الإنترنت اليومي.",
        callToAction = "تفاصيل العرض",
        highlightColor = RoyalBlueLight,
        ussdAction = "*2000#"
    ),
    PromoAd(
        id = "ad_cashback_wallet",
        sponsorName = "محفظتي الذكية",
        title = "كاش باك 20% على تحويل الأموال",
        description = "استرجع حتى 50 جنيهاً عند تحويل الأموال من محفظة الكاش هذا الأسبوع.",
        callToAction = "فتح المحفظة",
        highlightColor = SuccessGreen,
        ussdAction = "*9#"
    )
)

@Composable
fun AdBannerCard(
    modifier: Modifier = Modifier,
    ads: List<PromoAd> = DEFAULT_PROMO_ADS
) {
    val context = LocalContext.current
    var currentIndex by remember { mutableIntStateOf(0) }
    var isVisible by remember { mutableStateOf(true) }

    if (!isVisible || ads.isEmpty()) return
    val currentAd = ads[currentIndex % ads.size]

    AnimatedVisibility(visible = isVisible) {
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = NavySurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, currentAd.highlightColor.copy(alpha = 0.5f)),
            modifier = modifier
                .fillMaxWidth()
                .testTag("ad_banner_card")
        ) {
            Column(
                modifier = Modifier
                    .background(
                        Brush.linearGradient(
                            listOf(
                                NavySurfaceVariant.copy(alpha = 0.8f),
                                NavySurface
                            )
                        )
                    )
                    .padding(14.dp)
            ) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = currentAd.highlightColor.copy(alpha = 0.2f),
                            border = androidx.compose.foundation.BorderStroke(0.5.dp, currentAd.highlightColor)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Campaign,
                                    contentDescription = null,
                                    tint = currentAd.highlightColor,
                                    modifier = Modifier.size(12.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "إعلان مميز",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = currentAd.highlightColor
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = currentAd.sponsorName,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }

                    Row(verticalAlignment = Alignment.CenterVertically) {
                        if (ads.size > 1) {
                            Text(
                                text = "التالي",
                                fontSize = 10.sp,
                                color = GoldPrimary,
                                modifier = Modifier
                                    .clickable {
                                        currentIndex = (currentIndex + 1) % ads.size
                                    }
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                        IconButton(
                            onClick = { isVisible = false },
                            modifier = Modifier.size(24.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "إغلاق الإعلان",
                                tint = TextDim,
                                modifier = Modifier.size(14.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                Text(
                    text = currentAd.title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextWhite
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = currentAd.description,
                    fontSize = 11.sp,
                    color = TextMuted,
                    lineHeight = 16.sp
                )

                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "برعاية شبكات المحمول في مصر",
                        fontSize = 10.sp,
                        color = TextDim
                    )

                    Button(
                        onClick = {
                            if (currentAd.ussdAction != null) {
                                RealTelephonyService.dialUssd(context, currentAd.ussdAction)
                            } else {
                                Toast.makeText(context, "تم تفعيل العرض بنجاح!", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = currentAd.highlightColor,
                            contentColor = NavyDark
                        ),
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.height(34.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.LocalOffer,
                            contentDescription = null,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = currentAd.callToAction,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }
        }
    }
}
