package com.example.ui.screens

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkOperator
import com.example.ui.components.AdBannerCard
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.RoyalBlueLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.VodafoneRed

enum class FeedbackKind(val label: String) {
    SUGGESTION("اقتراح"),
    COMPLAINT("شكوى"),
    NEW_CODE("كود جديد")
}

data class FeedbackItem(
    val id: String,
    val kind: FeedbackKind,
    val title: String,
    val details: String,
    val timestamp: String = "الآن"
)

@Composable
fun FeedbackScreen(
    activeOperator: NetworkOperator,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var selectedKind by remember { mutableStateOf(FeedbackKind.SUGGESTION) }
    var codeTitle by remember { mutableStateOf("") }
    var codeValue by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }

    val submittedItems = remember {
        mutableStateListOf(
            FeedbackItem("1", FeedbackKind.NEW_CODE, "كود نت صيفي إضافي", "*2000*15# - فودافون", "منذ ساعة"),
            FeedbackItem("2", FeedbackKind.SUGGESTION, "تسريع قراءة الكروت", "ممتاز جداً وسريع أوفلاين", "أمس")
        )
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner matching HTML
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF1E3A8A).copy(alpha = 0.4f), // Blue-900/40
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF1E40AF)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(RoyalBlueLight.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Feedback, contentDescription = null, tint = RoyalBlueLight, modifier = Modifier.size(24.dp))
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column {
                        Text(
                            text = "الشكاوى والاقتراحات والأكواد",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFBFDBFE)
                        )
                        Text(
                            text = "أرسل اقتراحك، شكواك، أو أضف كوداً جديداً للمراجعة",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
            }
        }

        // Form
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = "نوع الإرسال",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        FeedbackKind.values().forEach { kind ->
                            val isSelected = selectedKind == kind
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = if (isSelected) RoyalBlueLight else NavyDark,
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (isSelected) RoyalBlueLight else NavyCardBorder
                                ),
                                modifier = Modifier
                                    .weight(1f)
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { selectedKind = kind }
                                    .testTag("feedback_kind_${kind.name.lowercase()}")
                            ) {
                                Box(
                                    modifier = Modifier.padding(vertical = 10.dp),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Text(
                                        text = kind.label,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (isSelected) Color.White else TextMuted
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    if (selectedKind == FeedbackKind.NEW_CODE) {
                        OutlinedTextField(
                            value = codeTitle,
                            onValueChange = { codeTitle = it },
                            placeholder = { Text("عنوان الكود (مثلاً: إلغاء الكول تون)", color = TextDim, fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("feedback_code_title"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RoyalBlueLight,
                                unfocusedBorderColor = NavyCardBorder,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        OutlinedTextField(
                            value = codeValue,
                            onValueChange = { codeValue = it },
                            placeholder = { Text("قيمة الكود (مثلاً: *155#)", color = TextDim, fontSize = 12.sp) },
                            singleLine = true,
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("feedback_code_value"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = RoyalBlueLight,
                                unfocusedBorderColor = NavyCardBorder,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                    }

                    OutlinedTextField(
                        value = message,
                        onValueChange = { message = it },
                        placeholder = {
                            Text(
                                text = when (selectedKind) {
                                    FeedbackKind.SUGGESTION -> "اكتب اقتراحك لتطوير التطبيق..."
                                    FeedbackKind.COMPLAINT -> "اكتب شكوتك بالتفصيل..."
                                    FeedbackKind.NEW_CODE -> "تفاصيل الكود واستخدامه..."
                                },
                                color = TextDim,
                                fontSize = 12.sp
                            )
                        },
                        minLines = 3,
                        maxLines = 5,
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("feedback_message_input"),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RoyalBlueLight,
                            unfocusedBorderColor = NavyCardBorder,
                            focusedTextColor = TextWhite,
                            unfocusedTextColor = TextWhite
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    Button(
                        onClick = {
                            if (message.isBlank()) {
                                Toast.makeText(context, "يرجى كتابة الرسالة / التفاصيل أولاً.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }
                            if (selectedKind == FeedbackKind.NEW_CODE && (codeTitle.isBlank() || codeValue.isBlank())) {
                                Toast.makeText(context, "يرجى إدخال عنوان الكود وقيمته.", Toast.LENGTH_SHORT).show()
                                return@Button
                            }

                            val title = if (selectedKind == FeedbackKind.NEW_CODE) codeTitle else "${selectedKind.label} بخصوص ${activeOperator.titleArabic}"
                            val detail = if (selectedKind == FeedbackKind.NEW_CODE) "$codeValue - $message" else message

                            submittedItems.add(
                                0,
                                FeedbackItem(
                                    id = System.currentTimeMillis().toString(),
                                    kind = selectedKind,
                                    title = title,
                                    details = detail,
                                    timestamp = "الآن"
                                )
                            )

                            Toast.makeText(context, "✅ تم إرسال ${selectedKind.label} بنجاح!", Toast.LENGTH_LONG).show()
                            message = ""
                            codeTitle = ""
                            codeValue = ""
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SuccessGreen,
                            contentColor = Color.White
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(48.dp)
                            .testTag("feedback_submit_button")
                    ) {
                        Icon(Icons.AutoMirrored.Filled.Send, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("إرسال", fontSize = 14.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Developer Direct Contact Cards matching HTML
        item {
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "تواصل مباشر مع المطور:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                try {
                                    val waIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/201080630060"))
                                    context.startActivity(waIntent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "+201080630060", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SuccessGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                        ) {
                            Icon(Icons.Default.Phone, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("واتساب المطور", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }

                        Button(
                            onClick = {
                                try {
                                    val emailIntent = Intent(Intent.ACTION_SENDTO, Uri.parse("mailto:abduahmed1422010.2@gmail.com")).apply {
                                        putExtra(Intent.EXTRA_SUBJECT, "تطبيق رصيدي - شكوى أو استفسار")
                                    }
                                    context.startActivity(emailIntent)
                                } catch (e: Exception) {
                                    Toast.makeText(context, "abduahmed1422010.2@gmail.com", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = VodafoneRed,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                        ) {
                            Icon(Icons.Default.Email, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("البريد الإلكتروني", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Recent feedback items
        items(submittedItems) { item ->
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = when (item.kind) {
                                    FeedbackKind.SUGGESTION -> RoyalBlueLight.copy(alpha = 0.2f)
                                    FeedbackKind.COMPLAINT -> VodafoneRed.copy(alpha = 0.2f)
                                    FeedbackKind.NEW_CODE -> SuccessGreen.copy(alpha = 0.2f)
                                }
                            ) {
                                Text(
                                    text = item.kind.label,
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (item.kind) {
                                        FeedbackKind.SUGGESTION -> RoyalBlueLight
                                        FeedbackKind.COMPLAINT -> VodafoneRed
                                        FeedbackKind.NEW_CODE -> SuccessGreen
                                    },
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = item.title,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = item.details,
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                    Text(
                        text = item.timestamp,
                        fontSize = 10.sp,
                        color = GoldPrimary
                    )
                }
            }
        }

        item {
            AdBannerCard()
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
