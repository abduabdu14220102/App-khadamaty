package com.example.ui.screens

import android.content.Context
import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.Feedback
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material.icons.filled.SupportAgent
import androidx.compose.material.icons.filled.Verified
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkOperator
import com.example.service.RealTelephonyService
import com.example.ui.components.AdBannerCard
import com.example.ui.components.SimSelectorCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.OrangeEgypt
import com.example.ui.theme.RoyalBlueLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.ui.theme.WarningOrange
import com.example.viewmodel.AppTab
import com.example.viewmodel.KhedmatyUiState

import com.example.ui.components.NativeTelephonyCard
import com.example.ui.components.EtisalatExclusiveCard
import com.example.ui.components.OrangeAssistanceCard

@Composable
fun DashboardScreen(
    uiState: KhedmatyUiState,
    onNavigateTab: (AppTab) -> Unit,
    onSelectSim: (Int) -> Unit,
    onEditNumberClick: () -> Unit,
    onRefreshSims: () -> Unit,
    onLaunchCameraModal: () -> Unit,
    onUpdateCardCode: (String) -> Unit,
    onRefreshStats: () -> Unit = {},
    onOpenNetTransfer: () -> Unit = {},
    onOpenFlexCalc: () -> Unit = {},
    onOpenDailyLimit: () -> Unit = {},
    onOpenFlexGuide: () -> Unit = {},
    onOpenUssdCompare: () -> Unit = {},
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val op = uiState.activeOperator

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // --- 1. Real Hardware SIM & Line Selector Card ---
        item {
            Spacer(modifier = Modifier.height(4.dp))
            SimSelectorCard(
                installedSims = uiState.installedSims,
                selectedSimIndex = uiState.selectedSimIndex,
                activeOperator = uiState.activeOperator,
                activePhoneNumber = uiState.activePhoneNumber,
                onSelectSim = onSelectSim,
                onEditNumberClick = onEditNumberClick
            )
        }

        // --- 1b. NATIVE TELEPHONY & SYSTEM STATS (Zero USSD Fees, Offline, Room Cache) ---
        item {
            NativeTelephonyCard(
                uiState = uiState,
                onRefreshStats = onRefreshStats,
                onOpenNetTransfer = onOpenNetTransfer,
                onOpenFlexCalc = onOpenFlexCalc,
                onOpenDailyLimit = onOpenDailyLimit,
                onOpenFlexGuide = onOpenFlexGuide,
                onOpenUssdCompare = onOpenUssdCompare
            )
        }

        // --- 1c. EXCLUSIVE OPERATOR FEATURES (Etisalat VIP & Orange Line Assistance) ---
        if (op == NetworkOperator.ETISALAT) {
            item {
                EtisalatExclusiveCard(context = context)
            }
        } else if (op == NetworkOperator.ORANGE) {
            item {
                OrangeAssistanceCard(
                    context = context,
                    onEditNumberClick = onEditNumberClick
                )
            }
        }

        // --- 2. FAST CARD RECHARGE WIDGET ---
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, op.brandColor.copy(alpha = 0.7f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("fast_card_recharge_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(op.brandColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.QrCodeScanner,
                                    contentDescription = null,
                                    tint = op.brandColor,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "شحن كارت سريع (${op.titleArabic})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Text(
                                    text = "اكتب الكود أو امسحه بالكاميرا أوفلاين",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = op.brandColor
                        ) {
                            Text(
                                text = "14 - 16 رقم",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Input Field with Camera Launcher Icon
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = uiState.cardCodeInput,
                            onValueChange = onUpdateCardCode,
                            placeholder = { Text("اكتب كود الكارت (14 إلى 16 رقماً)", color = TextDim, fontSize = 12.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            singleLine = true,
                            modifier = Modifier
                                .weight(1f)
                                .testTag("fast_card_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = GoldPrimary,
                                unfocusedBorderColor = NavyCardBorder,
                                focusedTextColor = TextWhite,
                                unfocusedTextColor = TextWhite,
                                focusedContainerColor = NavyDark,
                                unfocusedContainerColor = NavyDark
                            ),
                            shape = RoundedCornerShape(12.dp)
                        )

                        // Camera Button to launch Camera OCR
                        IconButton(
                            onClick = onLaunchCameraModal,
                            modifier = Modifier
                                .size(50.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(NavyDark)
                                .border(1.dp, GoldPrimary, RoundedCornerShape(12.dp))
                                .testTag("fast_card_camera_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.CameraAlt,
                                contentDescription = "مسح الكارت بالكاميرا",
                                tint = GoldPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // 2 Fast Action Buttons
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (uiState.cardCodeInput.isBlank()) {
                                    Toast.makeText(context, "يرجى كتابة رقم الكارت أولاً أو مسحه بالكاميرا", Toast.LENGTH_SHORT).show()
                                } else {
                                    val ussd = RealTelephonyService.formatRechargeUssd(op, uiState.cardCodeInput, isNetOnly = false)
                                    RealTelephonyService.dialUssd(context, ussd)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = op.brandColor,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                        ) {
                            Text(
                                text = op.rechargeLabel,
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = {
                                if (uiState.cardCodeInput.isBlank()) {
                                    Toast.makeText(context, "يرجى كتابة رقم الكارت أولاً أو مسحه بالكاميرا", Toast.LENGTH_SHORT).show()
                                } else {
                                    val ussd = RealTelephonyService.formatRechargeUssd(op, uiState.cardCodeInput, isNetOnly = true)
                                    RealTelephonyService.dialUssd(context, ussd)
                                }
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SuccessGreen,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(44.dp)
                        ) {
                            Text(
                                text = "شحن إنترنت فقط",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }

        // --- 3. 3 QUICK ACTION SHORTCUTS (Balance, Cash, Internet) ---
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // 1. Balance
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, op.brandColor.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { RealTelephonyService.dialUssd(context, op.ussdBalanceCode) }
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(op.brandColor.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = op.brandColor, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("استعلام رصيد", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text(op.ussdBalanceCode, fontSize = 10.sp, color = GoldLight)
                    }
                }

                // 2. Cash Balance
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { RealTelephonyService.dialUssd(context, op.ussdCashBalanceCode) }
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AccountBalanceWallet, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("رصيد الكاش", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text(op.ussdCashBalanceCode, fontSize = 10.sp, color = GoldLight)
                    }
                }

                // 3. Internet Packages
                Surface(
                    color = NavySurface,
                    shape = RoundedCornerShape(14.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RoyalBlueLight.copy(alpha = 0.5f)),
                    modifier = Modifier
                        .weight(1f)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { RealTelephonyService.dialUssd(context, op.ussdInternetCode) }
                ) {
                    Column(
                        modifier = Modifier.padding(vertical = 12.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(RoyalBlueLight.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Wifi, contentDescription = null, tint = RoyalBlueLight, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text("باقات النت", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                        Text(op.ussdInternetCode, fontSize = 10.sp, color = GoldLight)
                    }
                }
            }
        }

        // --- 4. SPONSORED AD BANNER ---
        item {
            AdBannerCard()
        }

        // --- 5. DETECTED NETWORK FULL DOSSIER & REAL USSD CONTROLS ---
        item {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, op.brandColor.copy(alpha = 0.6f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("detected_network_dossier")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(42.dp)
                                    .clip(CircleShape)
                                    .background(op.brandColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.PhoneAndroid,
                                    contentDescription = null,
                                    tint = op.brandColor,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = op.titleArabic,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Icon(
                                        imageVector = Icons.Default.Verified,
                                        contentDescription = "Verified",
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                                Text(
                                    text = "شبكة المحمول المكتشفة",
                                    fontSize = 11.sp,
                                    color = TextMuted
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = NavyDark
                        ) {
                            Text(
                                text = "4G LTE / 5G",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = SuccessGreen,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Customer service
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NavyDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.SupportAgent,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "خدمة عملاء ${op.titleArabic}: ${op.customerServiceNumber}",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = TextWhite
                                )
                            }
                            Button(
                                onClick = { RealTelephonyService.dialUssd(context, op.customerServiceNumber) },
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = op.brandColor,
                                    contentColor = Color.White
                                ),
                                modifier = Modifier.height(30.dp)
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(12.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("اتصال", fontSize = 10.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = "أكواد فورية هامة:",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = GoldLight
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        DirectUssdActionButton(
                            label = "سلفني",
                            code = when (op) {
                                NetworkOperator.VODAFONE -> "*3#"
                                NetworkOperator.ORANGE -> "#444#"
                                NetworkOperator.ETISALAT -> "*911#"
                                NetworkOperator.WE -> "*504#"
                            },
                            color = OrangeEgypt,
                            modifier = Modifier.weight(1f),
                            onClick = {
                                val code = when (op) {
                                    NetworkOperator.VODAFONE -> "*3#"
                                    NetworkOperator.ORANGE -> "#444#"
                                    NetworkOperator.ETISALAT -> "*911#"
                                    NetworkOperator.WE -> "*504#"
                                }
                                RealTelephonyService.dialUssd(context, code)
                            }
                        )
                        DirectUssdActionButton(
                            label = "معرفة رقمي",
                            code = op.ussdMyNumberCode,
                            color = GoldPrimary,
                            modifier = Modifier.weight(1f),
                            onClick = { RealTelephonyService.dialUssd(context, op.ussdMyNumberCode) }
                        )
                        DirectUssdActionButton(
                            label = "إلغاء الاشتراكات",
                            code = "*155#",
                            color = WarningOrange,
                            modifier = Modifier.weight(1f),
                            onClick = { RealTelephonyService.dialUssd(context, "*155#") }
                        )
                    }
                }
            }
        }

        // --- 6. Featured Banner: Free Net ---
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    Brush.horizontalGradient(listOf(GoldPrimary, GoldAccent, op.brandColor))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(20.dp))
                    .clickable { onNavigateTab(AppTab.FREE_NET) }
                    .testTag("featured_free_net_banner")
            ) {
                Row(
                    modifier = Modifier.padding(18.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(GoldPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Wifi,
                                contentDescription = null,
                                tint = GoldPrimary,
                                modifier = Modifier.size(26.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "نت مجاني وهدايا حصرية",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = TextWhite
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = GoldPrimary
                                ) {
                                    Text(
                                        text = "مجاني 100%",
                                        fontSize = 10.sp,
                                        color = NavyDark,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "عروض الميجابايتس اليومية لشريحة ${op.titleArabic}",
                                fontSize = 11.sp,
                                color = GoldLight
                            )
                        }
                    }
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                        contentDescription = "عرض",
                        tint = GoldPrimary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
        }

        // --- 6b. Featured Special Promo: *890# Etisalat 2GB ---
        item {
            Surface(
                shape = RoundedCornerShape(20.dp),
                color = Color(0xFF0F291E),
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    Brush.horizontalGradient(listOf(Color(0xFF22C55E), GoldPrimary, Color(0xFF15803D)))
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("featured_etisalat_890_card")
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "⭐ كود *890# اتصالات (مميز 2 جيجا)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.ExtraBold,
                            color = GoldLight
                        )
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFF22C55E)
                        ) {
                            Text(
                                text = "2 جيجا هدية",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "عرض حصري لعملاء اتصالات e&: 2000 ميجابايت (2 جيجا) إنترنت هدية فورية لخطك بدون أي شروط.",
                        fontSize = 11.sp,
                        color = TextWhite.copy(alpha = 0.9f)
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { RealTelephonyService.dialUssd(context, "*890#") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = Color(0xFF22C55E),
                                contentColor = Color.Black
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(42.dp)
                                .testTag("btn_dial_890")
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اطلب *890# الآن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }

                        Button(
                            onClick = { RealTelephonyService.copyToClipboard(context, "*890#", "تم نسخ كود *890# اتصالات (2 جيجا)!") },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = NavyDark,
                                contentColor = TextWhite
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.height(42.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("نسخ", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // --- 7. Main App Modules Grid ---
        item {
            Text(
                text = "خدمات وأقسام التطبيق:",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ModuleCard(
                    title = "قارئ كروت الشحن",
                    subtitle = "مسح سريع أوفلاين OCR",
                    icon = Icons.Default.DocumentScanner,
                    tint = GoldPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(AppTab.SCANNER) }
                )
                ModuleCard(
                    title = "دليل الأكواد الشامل",
                    subtitle = "جميع أكواد خدمات الشبكات",
                    icon = Icons.Default.PhoneAndroid,
                    tint = RoyalBlueLight,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(AppTab.CODES) }
                )
            }
            Spacer(modifier = Modifier.height(10.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                ModuleCard(
                    title = "محفظة الكاش",
                    subtitle = "تحويل واستعلام كاش مباشر",
                    icon = Icons.Default.AccountBalanceWallet,
                    tint = SuccessGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(AppTab.WALLET_CODES) }
                )
                ModuleCard(
                    title = "الاقتراحات والشكاوى",
                    subtitle = "إرسال كود جديد وتواصل",
                    icon = Icons.Default.Feedback,
                    tint = OrangeEgypt,
                    modifier = Modifier.weight(1f),
                    onClick = { onNavigateTab(AppTab.FEEDBACK) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun DirectUssdActionButton(
    label: String,
    code: String,
    color: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = NavyDark,
        shape = RoundedCornerShape(12.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, color.copy(alpha = 0.5f)),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onClick)
    ) {
        Column(
            modifier = Modifier.padding(vertical = 10.dp, horizontal = 6.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text(
                text = label,
                fontSize = 11.sp,
                fontWeight = FontWeight.Bold,
                color = TextWhite
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = code,
                fontSize = 11.sp,
                fontWeight = FontWeight.ExtraBold,
                color = color
            )
            Spacer(modifier = Modifier.height(4.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Call, contentDescription = null, tint = color, modifier = Modifier.size(10.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text(text = "طلب فوري", fontSize = 9.sp, color = color)
            }
        }
    }
}

@Composable
fun ModuleCard(
    title: String,
    subtitle: String,
    icon: ImageVector,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Surface(
        color = NavySurface,
        shape = RoundedCornerShape(16.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(tint.copy(alpha = 0.15f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(imageVector = icon, contentDescription = title, tint = tint, modifier = Modifier.size(20.dp))
            }
            Spacer(modifier = Modifier.height(8.dp))
            Text(text = title, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = TextWhite)
            Text(text = subtitle, fontSize = 11.sp, color = TextMuted)
        }
    }
}
