package com.example.ui.screens

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.FreeNetCategory
import com.example.model.FreeNetCatalog
import com.example.model.FreeNetCode
import com.example.model.NetworkOperator
import com.example.service.RealTelephonyService
import com.example.ui.components.AdBannerCard
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import com.example.viewmodel.KhedmatyUiState

@Composable
fun FreeNetScreen(
    uiState: KhedmatyUiState,
    onFilterChange: (NetworkOperator?, FreeNetCategory?) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val filteredList = FreeNetCatalog.allFreeCodes.filter { item ->
        val matchesOp = uiState.selectedFreeNetOperator == null ||
                item.operator == uiState.selectedFreeNetOperator ||
                item.operator == null
        val matchesCat = uiState.selectedFreeNetCategory == null ||
                item.category == uiState.selectedFreeNetCategory
        matchesOp && matchesCat
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(NavyDark)
            .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Hero Banner
        item {
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = NavySurface,
                border = androidx.compose.foundation.BorderStroke(
                    1.5.dp,
                    Brush.horizontalGradient(listOf(GoldPrimary, GoldAccent, NavyCardBorder))
                ),
                modifier = Modifier.fillMaxWidth()
            ) {
                Box(modifier = Modifier.padding(18.dp)) {
                    Column {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(38.dp)
                                        .clip(CircleShape)
                                        .background(GoldPrimary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Wifi,
                                        contentDescription = "Free Net",
                                        tint = GoldPrimary,
                                        modifier = Modifier.size(22.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "دليل الإنترنت المجاني والعروض",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite
                                    )
                                    Text(
                                        text = "أحدث الهدايا الرسمية لشبكات مصر",
                                        fontSize = 11.sp,
                                        color = GoldLight
                                    )
                                }
                            }
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SuccessGreen.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "مجاني 100%",
                                    fontSize = 10.sp,
                                    color = SuccessGreen,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Operator Filter Pills
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    val isAll = uiState.selectedFreeNetOperator == null
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isAll) GoldPrimary else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isAll) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onFilterChange(null, uiState.selectedFreeNetCategory) }
                    ) {
                        Text(
                            text = "الكل",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isAll) NavyDark else TextWhite,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
                items(NetworkOperator.values()) { op ->
                    val isSelected = uiState.selectedFreeNetOperator == op
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = if (isSelected) op.brandColor else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(12.dp))
                            .clickable { onFilterChange(op, uiState.selectedFreeNetCategory) }
                            .testTag("free_net_op_${op.id}")
                    ) {
                        Text(
                            text = op.titleArabic,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isSelected) Color.White else TextWhite,
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)
                        )
                    }
                }
            }
        }

        // Category Filter Chips
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                item {
                    val isAll = uiState.selectedFreeNetCategory == null
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isAll) NavySurfaceVariant else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isAll) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onFilterChange(uiState.selectedFreeNetOperator, null) }
                    ) {
                        Text(
                            text = "جميع الأقسام",
                            fontSize = 11.sp,
                            color = if (isAll) GoldPrimary else TextMuted,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
                items(FreeNetCategory.values()) { cat ->
                    val isSelected = uiState.selectedFreeNetCategory == cat
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (isSelected) NavySurfaceVariant else NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, if (isSelected) GoldPrimary else NavyCardBorder),
                        modifier = Modifier
                            .clip(RoundedCornerShape(10.dp))
                            .clickable { onFilterChange(uiState.selectedFreeNetOperator, cat) }
                    ) {
                        Text(
                            text = cat.titleArabic,
                            fontSize = 11.sp,
                            color = if (isSelected) GoldPrimary else TextMuted,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                        )
                    }
                }
            }
        }

        // Free Net Cards
        items(filteredList) { freeCode ->
            val brandColor = freeCode.operator?.brandColor ?: GoldPrimary
            val operatorTitle = freeCode.operator?.titleArabic ?: "كود عام موحد"

            val is890Special = freeCode.code == "*890#"

            Surface(
                color = if (is890Special) Color(0xFF0F291E) else NavySurface,
                shape = RoundedCornerShape(18.dp),
                border = androidx.compose.foundation.BorderStroke(
                    if (is890Special) 2.dp else 1.dp,
                    if (is890Special) Color(0xFF22C55E) else NavyCardBorder
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("free_code_card_${freeCode.id}")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(10.dp)
                                    .clip(CircleShape)
                                    .background(brandColor)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = operatorTitle,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                            if (is890Special) {
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = Color(0xFF22C55E)
                                ) {
                                    Text(
                                        text = "⭐ مميز 2 جيجا",
                                        fontSize = 10.sp,
                                        fontWeight = FontWeight.ExtraBold,
                                        color = Color.Black,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                    )
                                }
                            }
                        }
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = NavyDark
                        ) {
                            Text(
                                text = freeCode.category.titleArabic,
                                fontSize = 10.sp,
                                color = GoldLight,
                                fontWeight = FontWeight.Medium,
                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = freeCode.title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = TextWhite
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = SuccessGreen,
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = freeCode.quotaDescription,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = GoldPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(text = "الصلاحية: ${freeCode.validityPeriod}", fontSize = 11.sp, color = TextMuted)
                    Text(text = "الشرط: ${freeCode.condition}", fontSize = 11.sp, color = TextMuted)

                    Spacer(modifier = Modifier.height(14.dp))

                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = NavyDark,
                        border = androidx.compose.foundation.BorderStroke(1.dp, brandColor.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = freeCode.code,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.ExtraBold,
                                color = GoldLight,
                                letterSpacing = 1.sp
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                OutlinedButton(
                                    onClick = { RealTelephonyService.copyToClipboard(context, freeCode.code) },
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("نسخ", fontSize = 11.sp)
                                }

                                Button(
                                    onClick = { RealTelephonyService.dialUssd(context, freeCode.code) },
                                    shape = RoundedCornerShape(8.dp),
                                    colors = ButtonDefaults.buttonColors(
                                        containerColor = brandColor,
                                        contentColor = Color.White
                                    ),
                                    modifier = Modifier.height(34.dp)
                                ) {
                                    Icon(Icons.Default.Call, contentDescription = null, modifier = Modifier.size(13.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("اتصال", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            AdBannerCard()
        }

        item {
            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}
