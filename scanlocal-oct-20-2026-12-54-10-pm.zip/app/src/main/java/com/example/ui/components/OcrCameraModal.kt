package com.example.ui.components

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.os.Build
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import android.view.ViewGroup
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.annotation.OptIn
import androidx.camera.core.Camera
import androidx.camera.core.CameraSelector
import androidx.camera.core.ExperimentalGetImage
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DocumentScanner
import androidx.compose.material.icons.filled.FlashOff
import androidx.compose.material.icons.filled.FlashOn
import androidx.compose.material.icons.filled.QrCodeScanner
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import androidx.core.content.ContextCompat
import com.example.model.NetworkOperator
import com.example.service.ImageOcrProcessor
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.RoyalBlueLight
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite
import kotlinx.coroutines.launch
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean

/**
 * CameraModal: Carbon copy of the HTML Camera/OCR Modal component
 * Replicates the exact visual appearance, .roi-overlay box (80% x 25%),
 * button labels ("قراءة الكود الآن" & "إغلاق"), Tesseract-style offline OCR processing,
 * and automatic code insertion into the recharge input.
 */
@OptIn(ExperimentalGetImage::class)
@Composable
fun OcrCameraModal(
    isOpen: Boolean,
    selectedNetwork: NetworkOperator,
    onClose: () -> Unit,
    onCodeRead: (String) -> Unit,
    onShowToast: (String) -> Unit
) {
    if (!isOpen) return

    val context = LocalContext.current
    val lifecycleOwner = LocalLifecycleOwner.current
    val coroutineScope = rememberCoroutineScope()

    var hasCameraPermission by remember {
        mutableStateOf(
            ContextCompat.checkSelfPermission(context, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED
        )
    }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        hasCameraPermission = granted
        if (!granted) {
            onShowToast("يجب منح إذن الكاميرا للمتابعة.")
        }
    }

    LaunchedEffect(Unit) {
        if (!hasCameraPermission) {
            permissionLauncher.launch(Manifest.permission.CAMERA)
        }
    }

    // Modal state matching HTML
    var ocrStatus by remember { mutableStateOf("جاري تهيئة OCR...") }
    var ocrProcessing by remember { mutableStateOf(false) }
    var isCameraReady by remember { mutableStateOf(false) }
    var isTorchEnabled by remember { mutableStateOf(false) }
    var cameraControlInstance by remember { mutableStateOf<Camera?>(null) }
    var isAutoContinuousScan by remember { mutableStateOf(false) }

    val triggerManualScan = remember { AtomicBoolean(false) }

    // Laser scanning animation inside the ROI
    val infiniteTransition = rememberInfiniteTransition(label = "laser_anim_transition")
    val laserY by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 1f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "laser_y"
    )

    Dialog(
        onDismissRequest = onClose,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.90f))
                .padding(16.dp),
            contentAlignment = Alignment.Center
        ) {
            Surface(
                shape = RoundedCornerShape(22.dp),
                color = NavyDark,
                border = androidx.compose.foundation.BorderStroke(1.5.dp, NavyCardBorder),
                shadowElevation = 24.dp,
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("camera_ocr_modal")
            ) {
                Column(modifier = Modifier.padding(16.dp)) {

                    // Modal Header matching HTML: "قارئ كارت الشحن (OCR)"
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(selectedNetwork.brandColor.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DocumentScanner,
                                    contentDescription = null,
                                    tint = selectedNetwork.brandColor,
                                    modifier = Modifier.size(18.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "قارئ كارت الشحن (OCR)",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        }

                        // Network Pill Badge
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = selectedNetwork.brandColor
                        ) {
                            Text(
                                text = selectedNetwork.titleArabic,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Video Container with .roi-overlay
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .aspectRatio(16f / 9f)
                            .clip(RoundedCornerShape(16.dp))
                            .background(NavySurface)
                            .border(1.dp, NavyCardBorder, RoundedCornerShape(16.dp))
                    ) {
                        if (!hasCameraPermission) {
                            Box(
                                modifier = Modifier.fillMaxSize(),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(
                                        imageVector = Icons.Default.CameraAlt,
                                        contentDescription = null,
                                        tint = ErrorRed,
                                        modifier = Modifier.size(44.dp)
                                    )
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Text(
                                        text = "إذن الكاميرا مطلوب",
                                        fontWeight = FontWeight.Bold,
                                        color = TextWhite,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.height(10.dp))
                                    Button(
                                        onClick = { permissionLauncher.launch(Manifest.permission.CAMERA) },
                                        colors = ButtonDefaults.buttonColors(containerColor = ErrorRed),
                                        shape = RoundedCornerShape(10.dp)
                                    ) {
                                        Text("منح الإذن الآن", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                                    }
                                }
                            }
                        } else {
                            val cameraExecutor = remember { Executors.newSingleThreadExecutor() }
                            var activeCameraProvider by remember { mutableStateOf<ProcessCameraProvider?>(null) }

                            AndroidView(
                                factory = { ctx ->
                                    val previewView = PreviewView(ctx).apply {
                                        layoutParams = ViewGroup.LayoutParams(
                                            ViewGroup.LayoutParams.MATCH_PARENT,
                                            ViewGroup.LayoutParams.MATCH_PARENT
                                        )
                                        scaleType = PreviewView.ScaleType.FILL_CENTER
                                        implementationMode = PreviewView.ImplementationMode.COMPATIBLE
                                    }

                                    val cameraProviderFuture = ProcessCameraProvider.getInstance(ctx)
                                    cameraProviderFuture.addListener({
                                        val cameraProvider = cameraProviderFuture.get()
                                        activeCameraProvider = cameraProvider
                                        val preview = Preview.Builder().build().also {
                                            it.setSurfaceProvider(previewView.surfaceProvider)
                                        }

                                        val imageAnalysis = ImageAnalysis.Builder()
                                            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
                                            .build()

                                        imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
                                            val shouldProcess = triggerManualScan.getAndSet(false) || isAutoContinuousScan
                                            if (shouldProcess && !ocrProcessing) {
                                                ocrProcessing = true
                                                ocrStatus = "جاري تحليل الصورة وقراءة الأرقام..."

                                                coroutineScope.launch {
                                                    val result = ImageOcrProcessor.analyzeFrame(
                                                        imageProxy,
                                                        selectedNetwork
                                                    )
                                                    ocrProcessing = false
                                                    ocrStatus = result.statusMessage

                                                    if (result.isSuccess && result.extractedPin != null) {
                                                        triggerHapticFeedback(ctx)
                                                        val confidenceStr = String.format("%.0f", result.confidence)
                                                        onShowToast("✅ تم سحب الكود بنجاح (دقة $confidenceStr%): ${result.extractedPin}")
                                                        onCodeRead(result.extractedPin)
                                                        onClose()
                                                    }
                                                }
                                            } else {
                                                imageProxy.close()
                                            }
                                        }

                                        try {
                                            cameraProvider.unbindAll()
                                            val cam = cameraProvider.bindToLifecycle(
                                                lifecycleOwner,
                                                CameraSelector.DEFAULT_BACK_CAMERA,
                                                preview,
                                                imageAnalysis
                                            )
                                            cameraControlInstance = cam
                                            isCameraReady = true
                                            ocrStatus = "الكاميرا جاهزة. اضغط 'قراءة الكود' بعد توجيه الكارت."
                                        } catch (exc: Exception) {
                                            Log.e("OcrCameraModal", "Binding failed", exc)
                                            ocrStatus = "❌ فشل تشغيل الكاميرا: ${exc.message}"
                                        }
                                    }, ContextCompat.getMainExecutor(ctx))

                                    previewView
                                },
                                modifier = Modifier.fillMaxSize(),
                                onRelease = {
                                    try {
                                        activeCameraProvider?.unbindAll()
                                    } catch (e: Exception) {
                                        Log.e("OcrCameraModal", "Error onRelease unbind", e)
                                    }
                                }
                            )

                            // 🌟 EXACT ROI OVERLAY REPLICA FROM HTML:
                            // width: 80%, height: 25%, border: 3px solid #ef4444, box-shadow: 0 0 15px rgba(239,68,68,0.9)
                            Box(
                                modifier = Modifier
                                    .fillMaxWidth(0.80f)
                                    .fillMaxSize(0.28f)
                                    .align(Alignment.Center)
                                    .shadow(
                                        elevation = 16.dp,
                                        shape = RoundedCornerShape(12.dp),
                                        spotColor = ErrorRed,
                                        ambientColor = ErrorRed
                                    )
                                    .background(ErrorRed.copy(alpha = 0.08f))
                                    .border(
                                        width = 3.dp,
                                        color = ErrorRed,
                                        shape = RoundedCornerShape(12.dp)
                                    )
                            ) {
                                // Sweeping laser line
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(2.5.dp)
                                        .align(Alignment.TopCenter)
                                        .padding(top = (laserY * 46).dp)
                                        .background(
                                            Brush.horizontalGradient(
                                                listOf(Color.Transparent, ErrorRed, Color.Transparent)
                                            )
                                        )
                                )
                            }

                            // Torch / Flash button on top right of video
                            IconButton(
                                onClick = {
                                    cameraControlInstance?.cameraControl?.let { ctrl ->
                                        isTorchEnabled = !isTorchEnabled
                                        ctrl.enableTorch(isTorchEnabled)
                                    }
                                },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(NavyDark.copy(alpha = 0.8f))
                            ) {
                                Icon(
                                    imageVector = if (isTorchEnabled) Icons.Default.FlashOn else Icons.Default.FlashOff,
                                    contentDescription = "كشاف",
                                    tint = if (isTorchEnabled) GoldPrimary else TextWhite,
                                    modifier = Modifier.size(18.dp)
                                )
                            }

                            // Offline OCR Badge on top left of video
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = NavyDark.copy(alpha = 0.85f),
                                border = androidx.compose.foundation.BorderStroke(0.5.dp, GoldPrimary),
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(8.dp)
                            ) {
                                Text(
                                    text = "⚡ أوفلاين OCR",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = GoldLight,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }

                            DisposableEffect(Unit) {
                                onDispose {
                                    try {
                                        activeCameraProvider?.unbindAll()
                                    } catch (e: Exception) {
                                        Log.e("OcrCameraModal", "Error unbinding: ${e.message}")
                                    }
                                    cameraExecutor.shutdown()
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // OCR Status message overlay bar
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = NavySurface,
                        border = androidx.compose.foundation.BorderStroke(1.dp, NavyCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.Center
                        ) {
                            if (ocrProcessing) {
                                CircularProgressIndicator(
                                    color = RoyalBlueLight,
                                    strokeWidth = 2.dp,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                            }
                            Text(
                                text = ocrStatus,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (ocrStatus.startsWith("✅")) SuccessGreen else TextWhite,
                                textAlign = TextAlign.Center
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Auto-scan Toggle row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المسح التلقائي المستمر للكود:",
                            fontSize = 12.sp,
                            color = TextMuted
                        )
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = if (isAutoContinuousScan) "مفعل" else "يدوي",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isAutoContinuousScan) SuccessGreen else TextMuted
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = isAutoContinuousScan,
                                onCheckedChange = { isAutoContinuousScan = it },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = SuccessGreen,
                                    uncheckedThumbColor = TextMuted,
                                    uncheckedTrackColor = NavySurface
                                ),
                                modifier = Modifier.size(32.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Modal Action Buttons matching HTML:
                    // 1. "قراءة الكود الآن" (Green, icon: scan-line)
                    // 2. "إغلاق" (Red)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Button(
                            onClick = {
                                triggerManualScan.set(true)
                            },
                            enabled = isCameraReady && !ocrProcessing,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = SuccessGreen,
                                contentColor = Color.White,
                                disabledContainerColor = NavySurfaceVariant,
                                disabledContentColor = TextMuted
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(46.dp)
                                .testTag("btn_read_code_now")
                        ) {
                            Icon(
                                imageVector = Icons.Default.QrCodeScanner,
                                contentDescription = null,
                                modifier = Modifier.size(18.dp)
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = if (ocrProcessing) "جاري القراءة..." else "قراءة الكود الآن",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Button(
                            onClick = onClose,
                            colors = ButtonDefaults.buttonColors(
                                containerColor = ErrorRed,
                                contentColor = Color.White
                            ),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .width(100.dp)
                                .height(46.dp)
                                .testTag("btn_close_ocr_modal")
                        ) {
                            Text(
                                text = "إغلاق",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

private fun triggerHapticFeedback(context: Context) {
    try {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as? VibratorManager
            vibratorManager?.defaultVibrator?.vibrate(
                VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE)
            )
        } else {
            @Suppress("DEPRECATION")
            val vibrator = context.getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator
            @Suppress("DEPRECATION")
            vibrator?.vibrate(150)
        }
    } catch (e: Exception) {
        // ignore
    }
}
