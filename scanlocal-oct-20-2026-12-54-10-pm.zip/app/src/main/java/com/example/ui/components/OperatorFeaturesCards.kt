package com.example.ui.components

import android.content.Context
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.PhoneAndroid
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.NetworkOperator
import com.example.service.RealTelephonyService
import com.example.ui.theme.EtisalatGreen
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.GoldLight
import com.example.ui.theme.GoldPrimary
import com.example.ui.theme.NavyCardBorder
import com.example.ui.theme.NavyDark
import com.example.ui.theme.NavySurface
import com.example.ui.theme.NavySurfaceVariant
import com.example.ui.theme.OrangeEgypt
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.TextDim
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextWhite

/**
 * 🌟 المميزات والعروض الحصرية لخطوط اتصالات مصر (e&)
 * تضم كود الهدية السحرية *890# (2 جيجا بايت مجاناً) وأهم خدمات اتصالات المعتمدة.
 */
@Composable
fun EtisalatExclusiveCard(
    context: Context,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = NavySurface,
        border = BorderStroke(
            1.5.dp,
            Brush.horizontalGradient(listOf(GoldPrimary, EtisalatGreen))
        ),
        modifier = modifier
            .fillMaxWidth()
            .testTag("etisalat_exclusive_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(EtisalatGreen.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Star,
                            contentDescription = null,
                            tint = GoldPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "مميزات وعروض اتصالات مصر (e&)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = GoldPrimary.copy(alpha = 0.2f)
                            ) {
                                Text(
                                    text = "حصري لخطك",
                                    fontSize = 10.sp,
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = "هدايا حصرية وباقات ميكسات معتمدة",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // ⭐ Highlighted Hero Feature: 2GB Gift (*890#)
            Surface(
                shape = RoundedCornerShape(16.dp),
                color = NavyDark,
                border = BorderStroke(1.5.dp, GoldPrimary),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(GoldPrimary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.CardGiftcard,
                                    contentDescription = null,
                                    tint = GoldPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    text = "هدية 2 جيجا إنترنت مجاناً",
                                    color = GoldPrimary,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 14.sp
                                )
                                Text(
                                    text = "كود اتصالات السحري الحصري للإنترنت",
                                    color = TextMuted,
                                    fontSize = 10.sp
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = GoldPrimary.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.6f))
                        ) {
                            Text(
                                text = "*890#",
                                color = GoldLight,
                                fontWeight = FontWeight.ExtraBold,
                                fontSize = 16.sp,
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { RealTelephonyService.dialUssd(context, "*890#") },
                            colors = ButtonDefaults.buttonColors(containerColor = GoldPrimary),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = NavyDark, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("اطلب 2 جيجا الآن", color = NavyDark, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = { RealTelephonyService.copyToClipboard(context, "*890#", "تم نسخ كود الهدية *890# بنجاح!") },
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.7f)),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = "نسخ", tint = GoldPrimary, modifier = Modifier.size(14.dp))
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Grid of Other Etisalat Key Services
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EtisalatMiniServiceCard(
                    title = "أقوى كارت وعروض الصيف",
                    code = "*011#",
                    subtitle = "ميكسات يومية مضاعفة",
                    modifier = Modifier.weight(1f),
                    onDial = { RealTelephonyService.dialUssd(context, "*011#") }
                )
                EtisalatMiniServiceCard(
                    title = "باقات سوبر كونكت",
                    code = "*566#",
                    subtitle = "باقات النت والسوشيال",
                    modifier = Modifier.weight(1f),
                    onDial = { RealTelephonyService.dialUssd(context, "*566#") }
                )
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                EtisalatMiniServiceCard(
                    title = "تحويل ميكسات اتصالات",
                    code = "*770#",
                    subtitle = "مشاركة الميكسات",
                    modifier = Modifier.weight(1f),
                    onDial = { RealTelephonyService.dialUssd(context, "*770#") }
                )
                EtisalatMiniServiceCard(
                    title = "اتصالات كاش (كود أساسي)",
                    code = "*777#",
                    subtitle = "تحويل وسحب واستعلام",
                    modifier = Modifier.weight(1f),
                    onDial = { RealTelephonyService.dialUssd(context, "*777#") }
                )
            }
        }
    }
}

@Composable
fun EtisalatMiniServiceCard(
    title: String,
    code: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onDial: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = NavyDark,
        border = BorderStroke(1.dp, NavyCardBorder),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onDial)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text(text = code, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = EtisalatGreen)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 9.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Call, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(10.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text(text = "طلب الكود المعتمد", fontSize = 9.sp, color = GoldPrimary, fontWeight = FontWeight.Bold)
            }
        }
    }
}

/**
 * 🍊 مساعد ومميزات خط أورانج مصر
 * يوفر كود معرفة رقم خط أورانج (#119#) وحفظ الرقم وحل مشكلة عدم قراءته التلقائية في الشريحة.
 */
@Composable
fun OrangeAssistanceCard(
    context: Context,
    onEditNumberClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        shape = RoundedCornerShape(22.dp),
        color = NavySurface,
        border = BorderStroke(1.5.dp, OrangeEgypt.copy(alpha = 0.8f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("orange_assistance_card")
    ) {
        Column(modifier = Modifier.padding(18.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(40.dp)
                            .clip(CircleShape)
                            .background(OrangeEgypt.copy(alpha = 0.2f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PhoneAndroid,
                            contentDescription = null,
                            tint = OrangeEgypt,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "مساعد ومميزات خط أورانج مصر",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = TextWhite
                            )
                        }
                        Text(
                            text = "اكتشاف الرقم بدقة والأكواد الأساسية المعتمدة",
                            fontSize = 11.sp,
                            color = TextMuted
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Number Detection Helper Box
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = NavyDark,
                border = BorderStroke(1.dp, OrangeEgypt.copy(alpha = 0.5f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = OrangeEgypt, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "لمعرفة رقم خط أورانج بدقة:",
                            color = GoldLight,
                            fontWeight = FontWeight.Bold,
                            fontSize = 12.sp
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "شرائح أورانج لا تُخزن الرقم على الشريحة. اطلب كود #119# لمعرفته فوراً واحفظه بالبرنامج بضغطة زر.",
                        color = TextWhite,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { RealTelephonyService.dialUssd(context, "#119#") },
                            colors = ButtonDefaults.buttonColors(containerColor = OrangeEgypt),
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .weight(1f)
                                .height(38.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("طلب #119# فوراً", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }

                        OutlinedButton(
                            onClick = onEditNumberClick,
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, GoldPrimary.copy(alpha = 0.8f)),
                            modifier = Modifier.height(38.dp)
                        ) {
                            Icon(Icons.Default.Edit, contentDescription = null, tint = GoldPrimary, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("حفظ الرقم", color = GoldPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Orange Key Services
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OrangeMiniServiceCard(
                    title = "أورنج كاش (كود أساسي)",
                    code = "#115#",
                    subtitle = "التحويل والسحب الرسمي",
                    modifier = Modifier.weight(1f),
                    onDial = { RealTelephonyService.dialUssd(context, "#115#") }
                )
                OrangeMiniServiceCard(
                    title = "باقات GO للإنترنت",
                    code = "#100*4#",
                    subtitle = "إدارة باقات النت",
                    modifier = Modifier.weight(1f),
                    onDial = { RealTelephonyService.dialUssd(context, "#100*4#") }
                )
            }
        }
    }
}

@Composable
fun OrangeMiniServiceCard(
    title: String,
    code: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    onDial: () -> Unit
) {
    Surface(
        shape = RoundedCornerShape(12.dp),
        color = NavyDark,
        border = BorderStroke(1.dp, NavyCardBorder),
        modifier = modifier
            .clip(RoundedCornerShape(12.dp))
            .clickable(onClick = onDial)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(text = title, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = TextWhite)
                Text(text = code, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = OrangeEgypt)
            }
            Spacer(modifier = Modifier.height(2.dp))
            Text(text = subtitle, fontSize = 9.sp, color = TextMuted)
            Spacer(modifier = Modifier.height(6.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Call, contentDescription = null, tint = OrangeEgypt, modifier = Modifier.size(10.dp))
                Spacer(modifier = Modifier.width(3.dp))
                Text(text = "طلب الكود المعتمد", fontSize = 9.sp, color = OrangeEgypt, fontWeight = FontWeight.Bold)
            }
        }
    }
}
